CHANGELOG
=========

V 2.0.0
------- 
 - Updated to bootstrap 4.1 version
 - Improved design
 - Removed deprecated plugins
 - Better management of vendor files
 - Other bug fixes

V 1.0.0
-------

 - Initial release