package ms.sp2.test.exception;

/**
 * @author 
 * 
 */
public enum HospitalServiceErrors {

	
	/**
	 * SUCCESS Response
	 */
	SUCCESS("0000", "Success"),

	/**
	 * FAILED Response
	 */

	GENERIC_EXCEPTION("EP0001", "Oops! Something Went Wrong, Unfortunately, We Are Unable To Process Your Request. Please <a href='http://www.doctospek.com/contact-us.htm' target='_blank' class=\"bold\">contact us</a> for further assistance."),
	
	GENERIC_EXCEPTION_HIBERNATE("EP0002", "Oops! Something Went Wrong, Unfortunately, We Are Unable To Process Your Request. Please <a href='http://www.doctospek.com/contact-us.htm' target='_blank' class=\\\"bold\\\">contact us</a> for further assistance."),
		
	
	SMS_SENDING_FAIL("HW-SMS-001","SMS Sending failed..."), 
	SMS_BALANCE_FEATCHING_FAIL("HW-SMS-002","SMS Balance fetching failed..."),
	SMS_DELIVERY_REPORT_FEATCHING_FAIL("HW-SMS-001","SMS Sending failed..."), 
	NO_ADDRESS_FOUND("DS-AS-001","Address Record Not Found...."),
	ADDRESS_ALREADY_EXIST("DS-AS-002","Address Record Already Exist....."), 
	NO_CERTIFICATE_FOUND("DS-CS-001","Certificate Record not found....."),
	CEITIFICATE_ALREADY_EXIST("DS-CS-002","Certificate Record already Exist....."),
	NO_PATIENT_FOUND("DS-PS-001","Patient Record Not Found."),
	PATIENT_ALREADY_EXIST("DS-PS-002","Patient Record Already Exist....."),
	INVALID_CREDENTIALS("DS-US-001","Invalid credentials..!"),
	INVALID_USER("DS-US-002","Invalid User...."),
	NO_DOCTOR_FOUND("DS-DS-001","Doctor Record Not Found..."),
	DOCTOR_ALREADY_EXIST("DS-DS-002","Doctor Record Already Exist..."),
	NO_PRESCRIPTION_FOUND("DS-PS-001", "Prescription Record Not Found..."),
	PRESCRIPTION_ALREADY_EXIST("DS-PS-002","Prescription Record Already Exist..."), 
	NO_ROLE_FOUND("DS-RS-001","User Role Record Not Found...."),
	ROLE_ALREADY_EXIST("DS-RS-002","Role Already Exist..."),
	NO_STAFF_FOUND("DS-SS-001","Staff Record Not Found...."),
	STAFF_ALREADY_EXIST("DS-SS-002","Staff Record Already Exist..."), 
	INVALID_INPUT("LD-LD-001","Invalid Input..."),
	BILL_NOT_FOUND("CB-SYS-001","Hospital Bill Record Not Found"), 
	SMS_CONFIG_NOT_FOUND("DS-SD-001","Sms setting configuration not found...."),
	SMS_TEMPLATE_NOT_FOUND("DS-SD-002","Sms Temaplet Not Found.........."),
	HOSPITAL_NOT_FOUND("DS-SD-005","Hospital Not found in system database.........."),
	
	HOSPITAL_BILL_NOT_FOUND("DS-SD-006","Hospital Bill is not found in system database.........."),
	PAYMENT_TYPE_RECORD_NOT_FOUND("DS-SD-007","Hospital Payment Type Not found in system database.........."),
	NO_HOSPITAL_PROPERTIES_NOT_FOUND("CP-CPA-001","Hospital properties Not found in system database.........."), 
	HOSPITAL_PROPERTIES_NOT_SAVED("CP-CPA-002","Hospital properties Not saved in system database.........."),
	ERROR_IN_UPDATE_BALANCE("PD-UB-001","Unable to update patient Balance......"),
	NO_BRANCH_FOUND("BD-GAB-001","Branch Record Not Found...."),
	BRANCH_NOT_SAVED("BD-GAB-002","Branch Not saved in system database.........."),
	
	ENABLE_TO_REGISTER_HOSPITAL("CR-SC-001","Error in register new hospital........."),
	HOSPITAL_PAYMENT_NOT_SAVED("CR-SC-002","Error in save hospital bill payment........."),
	HOSPITAL_PAYMENT_TYPE_NOT_FOUND("CR-SC-003","Hospital Payment type not found........."),
	 PAYMENT_PROVIDER_SETTING_NOT_FOUND("CR-SC-003","Hospital Payment Provider Setting not found........."),
	 HOSPITAL_ONLINE_PAYMENT_NOT_SAVED("SPC-COP-001","Hospital Online Payment Not Saved........."),
	 ROLE_NOT_SAVED("CR-SR-003","Error in save role........."), 
	 NO_EMPLOYEE_FOUND("CE-ES-001","Employee Record Not Found........."), 
	 EMPLOYEE_NOT_SAVED("EC-ES-002","Error in save Employee........."), 
	 EMAIL_IS_ALREADY_EXIST("EC-EE-003","Email is already Exist........."),
	 CONTACT_IS_ALREADY_EXIST("EC-EE-004","Contact is already Exist........."),
	 NO_FEE_STRUCTURE_FOUND("FC-GFS-001","Fee Structure Record Not Found........."),
	 FEE_STRUCTURE_NOT_SAVED("FC-SFS-003","Error in save Fee Structure........."),
	 BALANCE_NOT_UPDATED("PC-UB-001","Error in Update Balance........."),
	 NO_BALANCE_FOUND("PC-GRBC-001","Remaining Balance Record Not Found........."),
	 PATIENT_NOT_UPDATED("PC-UP-001","Error in Update Balance........."),
	 PATIENT_NOT_SAVED("PC-SP-001","Error in save Patient........."), 
	 NO_CITY_FOUND("CC-GAC-001","City Record Not Found........."),
	ALLERGY_NOT_SAVED("AC-SA-001","Error in save Allergy........."), 
	 NO_ALLERGY_FOUND("AC-GA-001","Allergy Record Not Found........."),
	 NO_SHIFT_FOUND("SC-GAS-001","Shift Record Not Found...."),
	SHIFT_NOT_SAVED("SC-SS-001","Shift Not saved in system database.........."),
	NO_STATE_FOUND("STC-GAS-001","State Record Not Found...."),
	NO_NOTICE_FOUND("NBC-GAN-001","Notice Record Not Found...."),
	NOTICE_NOT_SAVED("NBC-SN-001","Notice Not saved in system database.........."),
	HOSPITAL_NOT_SAVED("SAC-CR-001","Hospital Not Register Somthing is wrong..."),
	NO_SALES_ITEM_ASSET_FOUND("SIA-GSIA-001","Sales Item Image Record Not Found...."),
	NO_GLOBAL_SALE_ITEM_FOUND("GSC-GSI-001"," Sales Item Record Not Found...."),
	DOCUMENT_STATUS_NOT_CHANGED("SAC-DS-002","Hospital Document Status Not Changed Somthing is wrong..."),
	NO_SALES_ITEM_TYPE_FOUND("SIT-GSI-001","Sales Item Type Record Not Found...."),
	SALES_ITEM_TYPE_NOT_SAVED("SIT-SSI-001","Error in save Sales Item Type...."),
	EXPENSE_ITEM_NOT_SAVED("EIC-SEI-001","Error in save Expense Item ...."),
	NO_EXPENSE_ITEM_FOUND("EIC-GEI-001","Expense Item Record Not Found...."),
	NO_PATIENT_INV_REPORT_FOUND("PIR-GAR-001"," Patient Inventory Report Not Found...."),
	REPORT_ITEM_NOT_SAVED("PIR-SPIR-001","Error in save Patient Inv Report Item ...."),
	NO_HISTORY_FOUND("PSOC-GH-001","Patient History Not Found..."),
	PASSWORD_NOT_RESET("LC-RP-001","Error in reset password ...."),
	DASHBOARD_DATA_NOT_FOUND("LC-GDB-001","Dashboard data Not Found..."),
	DASHBOARD_PROPERTIES_NOT_SAVED("DPC-SDP-001","Error in save Patient Inv Report Item ...."),
	 NO_DOCUMENT_FOUND("CPGDC-GA-001","Document Not Found..."),
	 VENDOR_NOT_FOUND("VC-GA-001","Vendor Not Found..."),
		
	 EMPPATIENT_SETTING_LIST_NOT_FOUND("EPSC-GAEPL-001","Employee Patient Setting List Record Not Found...."),
	 EMPPATIENT_SETTING_NOT_SAVED("EPSC-SEPS-001","Error in save EmpPatient Setting...."),
	 EXPENSE_DETAILS_NOT_SAVED("EDC-SED-001","Error in save Expense Detail...."),
	 EMAIL_SETTING_NOT_FOUND("CESC-GESI-001","Email Setting Not Found..."),
	 NO_RECORD_FOUND("EC-GA-001","No expense record found...."),
	 NO_PATIENT_IN_WAITING_LIST("DS-PP-003","No Patient In Waiting List ...."),
	 NO_VENDOR_RECORD_FOUND("RC-GA-001","No Records Found ...."), 
	 EMAIL_SETTING_NOT_SAVED("CESC-SES-001","Error in save Email settings...."),
	 EMPLOYEE_SETTING_NOT_FOUND("ESC-GESI-001","Employee Setting Not Found...."),
	 EMPLOYEE_SETTING_NOT_SAVED("ESC-SES-001","Employee Setting Not saved...."),
	 NO_BRAND_FOUND("BC-GAB-001","Brand Not Found...."),
	 BRAND_NOT_SAVED("BC-SB-001","Error in Save Brand...."),
	 NO_CATEGORY_FOUND("CTGC-GAC-001","Category Not Found...."),
	 CATEGORY_NOT_SAVED("CTGC-GAC-001","Error in save Category...."),
	 NO_PATIENT_SALES_ORDER_FOUND("PSOC-GAPSO-001","Patient Sales Order Not Found...."),
	 NO_HOSPITAL_ITEM_FOUND("SC-SI-001","Hospital Item Not Found...."),
	 ITEM_NOT_FOUND("SC-SIBI-001","Item Not Found...."),
	 NO_DISEASE_FOUND("SC-SDBN-001","Disease Not Found...."),
	 NO_CERTIFICATE_HISTORY_FOUND("SC-PCH-001","Patient Certificate History Not Found...."), 
	 CERTIFICATE_NOT_SAVED("CRTC-SCRT-001","Certificate not saved...."),
	 PATIENT_SALES_ORDER_NOT_FOUND("PSOC-SPSO-001","Error in Save Patient Sales Order...."), 
	 NO_PATIENT_REPORT_FOUND("PRC-GAPR-001","Patient report not found."),
	 NO_HOSPITAL_REPORT_FOUND("SARC-GCRMN-001","Hospital report not found...."),
	 NO_REFERENCE_PERSON_FOUND("SAC-GRP-001","No refernce persons data found"),
	 REFERENCE_PERSON_NOT_SAVED("SAC-SRP-002","Error in save  reference person information...."),
	 PATIENT_INV_REPORT_NOT_SAVED("PIRC-PIRD-001","Error in Save Patient Investigation Report...."),
	 CHEQUE_STATUS_NOT_UPDATED("SARC-SCS-001","Error in update Cheque status...."),
	 CHEQUE_STATUS_NOT_FOUND("SARC-GCS-001","Cheque Status List not found...."),
	 HOSPITAL_PAYMENT_LIST_NOT_FOUND("SAC-GCPL-001","Hospital Payment List not found...."),
	 GEOLOCATION_CANT_SAVED("GLC-GLD-001","Geo location Setting Not Saved....."),
	 GEOLOCATION_NOT_FOUND("GLC-GLD-002","Geo location Setting Not Found....."),
	 PATIENT_HISTORY_NOT_FOUND("PRC-APC-001","Patient History Not Found..."),
	 DRAWER_ASSIGN_STATUS_NOT_CHANGE("EDC-AD-002","Assign Drawer Status Not Changed Somthing is wrong..."),
	 EXPENSE_HISTORY_NOT_FOUND("PRC-GEDR-001","Expense Details Not Found....."),
	 COLLECTION_HISTORY_NOT_FOUND("PRC-GCDR-001","Collection Details Not Found....."),
	 HOSPITAL_DRAWER_NOT_CREATED("LC-CCD-001","Hospital Drawer Not Created Somthing is wrong..."),
	 HOSPITAL_SMS_SETTING_STATUS_NOT_CHANGED("CSSC-CSSC-001","Hospital sms Setting status not updated..."),
	 ERROR_IN_COUNTING_HOSPITAL("SAC-GTCC-001","Hospital count Not Obtained....."),
	 PATIENT_ALL_HISTORY_NOT_FOUND("PC-GPAH-001","Hospital data  Not found....."),
	 NO_BRANCH_ALLOCATED("CE-ES-0333","There is no branch allocated to this user"),
	 USER_NOT_REGISTERED("REL-EL-404","This Mobile number is not registered.."),
	 INCOMPLETE_REGISTRATION("CB-SYS-003","This hospital not completed its registration"),
	 NO_TRANSACTION_DATA_FOUND("EC-GDT-004","Transaction data not found"),
	 EMPLOYEE_ALREADY_EXIST("EC-GDT-005","Employee already exist."), 
	 COLLECTION_RECORD_NOT_FOUND("PC-GDT-006","Collection record not found."), 
	 NO_VENDOR_FOUND("VA-GDT-006","Vendor record not found."), 
	 EXPENSE_RECORD_NOT_FOUND("EG-GDT-006","Expense record not found."), 
	 HANDOVER_RECORD_NOT_FOUND("EG-GDT-006","Handover record not found."),
	 HOSPITAL_ITEM_RECORD_FOUND("CG-GDT-006","Medicine record not found."), 
	 UPGRADE_SMS_REQ_NOT_FOUND("US-GUSR-001","Upgrade sms request not found."), 
	 EMPLOYEE_ATTENDANCE_RECORD_FOUND("CG-GDT-006","Employee attendance record not found."), 
	 PO_DRAFT_RECORD_NOT_FOUND("PG-GDT-006","Purchase order draft record not found."), 
	 PATIENT_INV_REPORT_NOT_FOUND("PIRC-PIRD-002","Patient investigation report not found."),
	 NO_CLIENT_RECORD_FOUND("ACC-ACGA-001","Client record not found..."),
	 NO_ADVERTISEMENT_RECORD_FOUND("AC-AGA-001","Advertisement record not found..."),
	 NO_CLIENT_BILL_RECORD_FOUND("ACC-ACGA-002","Clinet Bill record not found..."), 
	 BRANCH_NOT_UPDATED("CBC-SCS","Error in update cheque status..."), 
	 EMPLOYEE_ATTENDANCE_SETTING_LIST_NOT_FOUND("ACC-ACGA-006","Employee attendance setting list not found."), 
	 ATTENDANCE_SETTING_NOT_SAVED("ACC-ACGA-008","Attendance setting not saved."), 
	 NO_HOSPITAL_REFERENCE_FOUND("SAR-CRR-001","Hospital reference record not found"), 
	 NO_BRAND_RECORD_FOUND("POC-SB-001","Brand record not found"), 
	 NO_PARTNER_FOUND("PC-SB-001","Partner record not found"), 
	 NOT_SAVED_ITEM("PC-SB-005","Item not saved for shortage."), 
	 ROLE_NOT_FOUND("POC-SB-006","Role not found"),

	 SMS_SETTING_NOT_FOUND("SP-SB-005","Sms Setting Not Found"),
	 ALLREADYLOGGEDIN("SP-SB-008","You are already logged in from a different session. You want login again?."),
	 
	 HOSPITAL_PROPERTIES_NOT_FOUND("CP-CPA-001","Hospital properties Not found in system database.........."),
	 UNABLE_TO_REGISTER_HOSPITAL("CR-SC-001","Error in register new hospital.")
	 ;
	
	
	/**
	 * variable for error code
	 */
	private String errorCode;
	/**
	 * variable for error code
	 */
	private String errorDescription;

	/**
	 * @param errorCode
	 * @param errorDescription
	 */
	private HospitalServiceErrors(String errorCode, String errorDescription) {
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
	}

	/**
	 * @return error description
	 */
	public String getErrorDescription() {
		return this.errorDescription;
	}

	/**
	 * @return error code
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Enum#toString()
	 */
	public String toString() {
		return this.errorCode + ":" + this.errorDescription;
	}
}
