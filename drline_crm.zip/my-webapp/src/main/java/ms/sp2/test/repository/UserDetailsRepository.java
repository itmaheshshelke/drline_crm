/**
19-Jan-2019
* 
 */
package ms.sp2.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ms.sp2.test.jpa.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, Integer>{

	@Query("select u from UserDetails u where u.userId= :userId")
	UserDetails getUserById(@Param("userId") Integer userId);

}
