package ms.sp2.test.constants;

public class EmailConstant {

	public static final String TEMPLET_PATH="C:\\imp\\email_templates\\";
	public static final String USER_NAME ="flyonpaperless@gmail.com";
	public static final String USER_PASSWORD ="henx@1234";
	public static final String HOST ="smtp.gmail.com";
	public static final String PORT ="587";
	
	public static final String NEW_HOSPITAL="NEW_HOSPITAL";
	public static final String TRANS="TRANS";
	public static final Integer SENT=1;
	public static final Integer FAILED=2;
	
	
	public static final String DOCUMENTLIST="1.Board Resolution / Authorisation Letter for the Signing Authority duly signed and stamped by at least two Directors / Trustee /Members on the company letter head (avaihospitalle on dashboard after penny testing)\r\n" + 
			"2.Cancelled cheque Original Copy, IFSC code and Name should be printed.\r\n" + 
			"3.Copy of Pan Card copy of the Authorized signatory duly signed and stamped.\r\n" + 
			"4.Copy of Address Proof (Driving License/ Voter ID/ Aadhar Card/ Passport) duly signed and stamped.\r\n" + 
			"5.Copy of Company’s pan card duly signed and stamped by Authorized signatory.\r\n" + 
			"6.Copy of Company’s Govt. proof of the firm (Certificate of incorporation mandatory for Private Limited and Public Limited) duly signed and stamped.\r\n" + 
			"7.Copy of Form 18, if there is any change in address of the entity duly signed and stamped.\r\n" + 
			"8.Society Registration Certificate for filing status as society duly signed and stamped.\r\n" + 
			"9.Trust Act Certificate issued from Government for Trust duly signed and stamped.\r\n" + 
			"Mandatory Additional documents required in case taking donations: Form 80G duly signed and stamped – Form 12A duly signed and stamped.\r\n";
			
	
	public static final String SHAREASSMS="Dear ##1,##2Welcome to Drline!!! Here we are providing a link from which you can download your document ##3 ##4Thanks.Team Drline. Click here https://play.google.com/store/apps/details?id=in.drline to download the Drline App.";
	public static final String SHAREINVOICE="Dear ##1,##2Welcome to Drline!!! Here we are providing a link from which you can download your document ##3.##4Thanks,Team Drline";
	
	public static final String DAYTOEXPIOREADVEMAIL="Dear ##1,##2Welcome to Drline!!! This message is to inform you that your pay period of advertisement is expiring on ##3. In order to enjoy uninterupted service please re-activate advertise as soon.##4Thanks,Team Drline";
	

}
