/**
Created By : Namrata Malviya
19-Jan-2019
Branch.java 
* 
 */
package ms.sp2.test.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emp_user")
public class EmpUser implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 615683514595046381L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "emp_user_id")
	private Integer empUserId;

	@Column(name = "user_id")
	private Integer userId;

	@Column(name = "emp_id")
	private Integer empId;

	public Integer getEmpUserId() {
		return empUserId;
	}

	public void setEmpUserId(Integer empUserId) {
		this.empUserId = empUserId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

}
