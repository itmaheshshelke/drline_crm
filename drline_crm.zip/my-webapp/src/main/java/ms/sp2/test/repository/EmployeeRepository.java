/**
Created By : Vivek Patil
19-Jan-2019
* 
 */
package ms.sp2.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ms.sp2.test.jpa.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	@Query("select u from Employee u where u.delFlag = 'N' and u.contactNo1= :contactNo1")
	public Employee getEmployeeByhospital(@Param("contactNo1") String contactNo1);

	

	@Query("select u from Employee u where u.delFlag = 'N' and u.contactNo1= :mobNo ")
	public Employee isExistingContactForOtp(@Param("mobNo") String mobNo);
	
	
	
}
