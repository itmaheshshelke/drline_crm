package ms.sp2.test.dto.mapper;

import org.modelmapper.ModelMapper;

import ms.sp2.test.dto.SmsProviderSettingDto;
import ms.sp2.test.jpa.SmsProviderSetting;

public class SmsProviderSettingMapper {
	
	public static SmsProviderSettingDto _toDto(SmsProviderSetting smsProviderSetting) {

		ModelMapper mapper = new ModelMapper();
		SmsProviderSettingDto dtoObject = mapper.map(smsProviderSetting, SmsProviderSettingDto.class);
		return dtoObject;
	}

	public static SmsProviderSetting _toJpa(SmsProviderSettingDto SmsProviderSettingDto) {

		ModelMapper mapper = new ModelMapper();
		SmsProviderSetting jpaObject = mapper.map(SmsProviderSettingDto, SmsProviderSetting.class);
		return jpaObject;
	}


}
