package ms.sp2.test.dao;

import ms.sp2.test.dto.EmailPropertiesDto;
import ms.sp2.test.dto.SmsProviderSettingDto;
import ms.sp2.test.exception.HospitalExceptionHandler;

/**
 * created By : Mahesh Shelke
 *
 * created On : 22-Jan-2019
 */
public interface PropertiesDao {

public EmailPropertiesDto getEmailPropertiesById(Integer id) throws HospitalExceptionHandler;
	
	public SmsProviderSettingDto getSmsPropertiesById(Integer id) throws HospitalExceptionHandler;
}
