package ms.sp2.test.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ms.sp2.test.dto.EmployeeDto;
import ms.sp2.test.dto.UserDetailsDto;
import ms.sp2.test.dto.mapper.EmployeeMapper;
import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.exception.HospitalServiceErrors;
import ms.sp2.test.jpa.EmailInbox;
import ms.sp2.test.jpa.Employee;
import ms.sp2.test.jpa.UserDetails;
import ms.sp2.test.repository.EmpUserRepository;
import ms.sp2.test.repository.EmployeeRepository;
import ms.sp2.test.repository.UserDetailsRepository;
import ms.sp2.test.util.Util;

@Repository
@Transactional
public class LoginDaoImpl implements LoginDao{
	
	private Logger logger = LoggerFactory.getLogger(LoginDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	EmpUserRepository empUserRepository;
	
	
	@Autowired
	UserDetailsRepository userDetailsRepository;

	
	@Override
	public EmployeeDto login(UserDetailsDto userDetailsDto) throws HospitalExceptionHandler {
		EmployeeDto employeeDto=new EmployeeDto();
		UserDetails userDetails = new UserDetails();
		Employee employee = new Employee();
		try {
				employee = employeeRepository.getEmployeeByhospital(userDetailsDto.getUserName());
			
			if (employee != null) {
				employeeDto=EmployeeMapper._toDto(employee);
				
				Integer userId = empUserRepository.getEmpUserByEmpId(employee.getEmployeeId());
				userDetails = userDetailsRepository.getUserById(userId);

				if (userDetails.getUserId() != null) {
					if (Util.verifyPassword(userDetails.getSaltPassword(), userDetails.getPassword(),
							userDetailsDto.getPassword()) == true) {
						return employeeDto;
					} else {
						throw new HospitalExceptionHandler(HospitalServiceErrors.INVALID_CREDENTIALS);
					}
				} else {
					throw new HospitalExceptionHandler(HospitalServiceErrors.INVALID_CREDENTIALS);
				}

			} else {
				throw new HospitalExceptionHandler(HospitalServiceErrors.INVALID_CREDENTIALS);
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginDaoImpl - > login ", he);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (HospitalExceptionHandler hew) {
			throw hew;
		} catch (Exception e) {
			logger.error("Exception Error in LoginDaoImpl - > login ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		} 
	}

	@Override
	public Employee sendOtp(String mono, Integer hospitalId) throws HospitalExceptionHandler {
		Employee employee = new Employee();
		try {

			employee = employeeRepository.isExistingContactForOtp(mono);
			if (employee != null) {
				return employee;
			} else {
				throw new HospitalExceptionHandler(HospitalServiceErrors.NO_EMPLOYEE_FOUND);
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginDaoImpl - > sendOtp ", he);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (HospitalExceptionHandler hew) {
			throw hew;
		} catch (Exception e) {
			logger.error("Exception Error in LoginDaoImpl - > sendOtp ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
}

	@Override
	public Boolean resetPassword(Integer employeeId, String newPassword) throws HospitalExceptionHandler {
		Boolean result = false;
		try {
			Integer userId = empUserRepository.getEmpUserByEmpId(employeeId);
			UserDetails userDetails = userDetailsRepository.getUserById(userId);

			if (userDetails != null) {

				String salt = Util.generateSalt();
				String password = Util.generatePassword(salt, newPassword);
				// Add entry in user table
				userDetails.setPassword(password);
				userDetails.setFailedAttempt(0);
				userDetails.setSaltPassword(salt);
				userDetails.setStatus(1);
				entityManager.persist(userDetails);
				entityManager.flush();
				result = true;
			}
			if (result == true) {
				return result;
			} else {
				throw new HospitalExceptionHandler(HospitalServiceErrors.PASSWORD_NOT_RESET);
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginDaoImpl - > resetPassword ", he);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (HospitalExceptionHandler hew) {
			throw hew;
		} catch (Exception e) {
			logger.error("Exception Error in LoginDaoImpl - > resetPassword ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}finally {
			entityManager.close();
		}
	}

	@Override
	public Boolean saveNewPassword(String oldpasswrd, String newpasswrd, Integer employeeId) throws HospitalExceptionHandler {
	Boolean result = false;
	Boolean isPasswordCorrect = false;
	try {
		Integer userId = empUserRepository.getEmpUserByEmpId(employeeId);
		UserDetails userDetails = userDetailsRepository.getUserById(userId);

		if (Util.verifyPassword(userDetails.getSaltPassword(), userDetails.getPassword(), oldpasswrd) == true) {
			isPasswordCorrect = true;
		} else {
			throw new HospitalExceptionHandler(HospitalServiceErrors.INVALID_CREDENTIALS);
		}
		if (isPasswordCorrect) {

			String salt = Util.generateSalt();
			String password = Util.generatePassword(salt, newpasswrd);

			// Add entry in user table
			userDetails.setPassword(password);
			userDetails.setFailedAttempt(0);
			userDetails.setSaltPassword(salt);
			userDetails.setStatus(1);
			entityManager.persist(userDetails);
			entityManager.flush();
			result = true;
		}
		if (result == true) {
			return result;
		} else {
			throw new HospitalExceptionHandler(HospitalServiceErrors.INVALID_CREDENTIALS);
		}
	} catch (HibernateException he) {
		logger.error("HibernateException Error in LoginDaoImpl - > saveNewPassword ", he);
		throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
	} catch (HospitalExceptionHandler hew) {
		throw hew;
	} catch (Exception e) {
		logger.error("Exception Error in LoginDaoImpl - > saveNewPassword ", e);
		throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
	}finally {
		entityManager.close();
	}
}

	@Override
	@Transactional
	public Boolean saveEmail(EmailInbox emailInbox) throws HospitalExceptionHandler {
		Boolean result=false;
		try {

			entityManager.persist(emailInbox);
			entityManager.flush();
			result = true;
			if (result == true) {
				return result;
			} else {
				throw new HospitalExceptionHandler(HospitalServiceErrors.EMAIL_SETTING_NOT_SAVED);
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in GlobalRegDaoImpl - > saveEmail ", he);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		}catch(HospitalExceptionHandler hwe) {
			throw hwe;
		} catch (Exception e) {
			logger.error("Exception Error in GlobalRegDaoImpl - > saveEmail ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
	}
	
}

