package ms.sp2.test.dto.mapper;

/**
 * created by : Mahesh Shelke
   created on : 22-Jan-2019
 */

import org.modelmapper.ModelMapper;

import ms.sp2.test.dto.SmsProviderSettingDto;
import ms.sp2.test.jpa.SmsProviderSetting;

/**
 * created By : Mahesh Shelke
 *
 * created On : 22-Jan-2019
 */
public class SmsProviderMapper {

	public static SmsProviderSettingDto _toDto(SmsProviderSetting smsProviderSetting) {

		ModelMapper mapper = new ModelMapper();
		SmsProviderSettingDto dtoObject = mapper.map(smsProviderSetting, SmsProviderSettingDto.class);
		return dtoObject;
	}

	public static SmsProviderSetting _toJpa(SmsProviderSettingDto smsProviderSettingDto) {

		ModelMapper mapper = new ModelMapper();
		SmsProviderSetting jpaObject = mapper.map(smsProviderSettingDto, SmsProviderSetting.class);
		return jpaObject;
	}
}
