/**
/**
Created By : Vivek Patil
* 
 */
package ms.sp2.test.dto.mapper;

import org.modelmapper.ModelMapper;

import ms.sp2.test.dto.EmployeeDto;
import ms.sp2.test.jpa.Employee;

public class EmployeeMapper {

	public static EmployeeDto _toDto(Employee employee) {

		ModelMapper mapper = new ModelMapper();
		EmployeeDto dtoObject = mapper.map(employee, EmployeeDto.class);
		return dtoObject;
	}

	public static Employee _toJpa(EmployeeDto employeeDto) {

		ModelMapper mapper = new ModelMapper();
		Employee jpaObject = mapper.map(employeeDto, Employee.class);
		return jpaObject;
	}

}
