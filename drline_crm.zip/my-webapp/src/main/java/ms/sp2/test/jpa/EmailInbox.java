package ms.sp2.test.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="email_inbox")
public class EmailInbox implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    @Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="email_inbox_id")
    private Integer emailInboxId;
    
    @Column(name="email_template_type")
    private String emailTemplateType;
    
    @Column(name="email_transaction_id")
    private Integer emailTransactionId;
    
    @Column(name="service")
    private String service;
    
    @Column(name="status")
    private Integer status;

	public Integer getEmailInboxId() {
		return emailInboxId;
	}

	public void setEmailInboxId(Integer emailInboxId) {
		this.emailInboxId = emailInboxId;
	}

	public String getEmailTemplateType() {
		return emailTemplateType;
	}

	public void setEmailTemplateType(String emailTemplateType) {
		this.emailTemplateType = emailTemplateType;
	}

	public Integer getEmailTransactionId() {
		return emailTransactionId;
	}

	public void setEmailTransactionId(Integer emailTransactionId) {
		this.emailTransactionId = emailTransactionId;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	
    
}
