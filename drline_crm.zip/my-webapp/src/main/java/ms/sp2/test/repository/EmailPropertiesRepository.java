/**
 * created by : Mahesh Shelke
   created on : 23-Jan-2019
 */
package ms.sp2.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ms.sp2.test.jpa.EmailProperties;

/**
 * created By : Mahesh Shelke
 *
 * created On : 23-Jan-2019
 */
public interface EmailPropertiesRepository extends JpaRepository<EmailProperties, Integer>{

	@Query("Select e from EmailProperties e where e.emailPropertiesId =:emailPropertiesId ")
	public	EmailProperties getEmailPropertiesById(@Param("emailPropertiesId")Integer emailPropertiesId);

}
