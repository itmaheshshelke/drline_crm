package ms.sp2.test.logic;

import ms.sp2.test.dto.EmailMessage;
import ms.sp2.test.dto.EmailPropertiesDto;

public interface EmailLogic {

	public void send(EmailMessage message , EmailPropertiesDto emailPropertiesDto);
}
