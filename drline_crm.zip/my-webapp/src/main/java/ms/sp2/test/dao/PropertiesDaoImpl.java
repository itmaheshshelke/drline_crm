package ms.sp2.test.dao;

/**
 * created by : Mahesh Shelke
   created on : 22-Jan-2019
 */

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ms.sp2.test.dto.EmailPropertiesDto;
import ms.sp2.test.dto.SmsProviderSettingDto;
import ms.sp2.test.dto.mapper.EmailPropertiesMapper;
import ms.sp2.test.dto.mapper.SmsProviderMapper;
import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.exception.HospitalServiceErrors;
import ms.sp2.test.jpa.EmailProperties;
import ms.sp2.test.jpa.SmsProviderSetting;
import ms.sp2.test.repository.EmailPropertiesRepository;
import ms.sp2.test.repository.SmsProviderSettingRepository;

/**
 * created By : Mahesh Shelke
 *
 * created On : 22-Jan-2019
 */
@Repository
@Transactional
public class PropertiesDaoImpl implements PropertiesDao {

	Logger logger = LoggerFactory.getLogger(PropertiesDaoImpl.class);

	@Autowired
	private EmailPropertiesRepository emailPropertiesRepository;

	@Autowired
	private SmsProviderSettingRepository smsProviderSettingRepository;

	@Override
	public EmailPropertiesDto getEmailPropertiesById(Integer id) throws HospitalExceptionHandler {
		EmailPropertiesDto emailPropertiesDto = new EmailPropertiesDto();
		try {
			EmailProperties emailProperties = emailPropertiesRepository.getEmailPropertiesById(id);
			if (emailProperties != null) {
				emailPropertiesDto = EmailPropertiesMapper._toDto(emailProperties);
				return emailPropertiesDto;
			} else {
				throw new HospitalExceptionHandler(HospitalServiceErrors.EMAIL_SETTING_NOT_FOUND);
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in PropertiesDaoImpl - > getEmailPropertiesByBranchId() ", he);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (HospitalExceptionHandler hew) {
			throw hew;
		} catch (Exception e) {
			logger.error("Exception Error in PropertiesDaoImpl - > getEmailPropertiesByBranchId() ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}

	}

	@Override
	public SmsProviderSettingDto getSmsPropertiesById(Integer id) throws HospitalExceptionHandler {
		SmsProviderSettingDto smsProviderSettingDto = new SmsProviderSettingDto();
		try {
			SmsProviderSetting SmsProviderSetting = smsProviderSettingRepository.getSmsPropertiesById(id);
			if (SmsProviderSetting != null) {
				smsProviderSettingDto = SmsProviderMapper._toDto(SmsProviderSetting);
				return smsProviderSettingDto;
			} else {
				throw new HospitalExceptionHandler(HospitalServiceErrors.SMS_SETTING_NOT_FOUND);
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in PropertiesDaoImpl - > getSmsPropertiesByBranchId() ", he);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (HospitalExceptionHandler hew) {
			throw hew;
		} catch (Exception e) {
			logger.error("Exception Error in PropertiesDaoImpl - > getSmsPropertiesByBranchId() ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
	}

}
