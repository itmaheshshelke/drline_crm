package ms.sp2.test.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import ms.sp2.test.dto.EmailMessage;
import ms.sp2.test.dto.EmailPropertiesDto;

public class EmailUtil {
	
	public static boolean sendEmail(EmailPropertiesDto emailPropertiesDto,EmailMessage emailMessage, String contents) {
		// LOG.info("EmailUtils: sendEmail method STARTS");
		Integer maxRetryCount = 3;// MessageAttributeConstants.MAX_REDELIVERYCOUNT;

		// LOG.info("After cachedata");
		final String username = emailPropertiesDto.getEmailId();//PropertyHandler.getProperty(siteId+".spin.serivce.email.email");// emailSetings.getEmail_id();//emailConfig.getSmtpUserName();
		final String password = emailPropertiesDto.getPassword();//PropertyHandler.getProperty(siteId+".spin.serivce.email.password");// emailSetings.getPassword();//emailConfig.getSmtpUserPassword();

		boolean emailSent = false;
		List<InternetAddress> lstAddresses = null;
		try {
			Properties props = new Properties();
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");//PropertyHandler.getProperty(siteId+".spin.serivce.email.host"));
			props.put("mail.smtp.port", emailPropertiesDto.getPort().toString());//PropertyHandler.getProperty(siteId+".spin.serivce.email.port"));
			props.put("mail.smtp.timeout", "60000");
			props.put("mail.smtp.connectiontimeout", "60000");
			props.put("mail.smtp.ssl.trust", "*");

			Session session = null;
			if ("true" == null || "true".trim().equalsIgnoreCase("false")) {
				session = Session.getInstance(props);
			} else {
				session = Session.getInstance(props, new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username, password);
					}
				});
			}

			while (emailSent == false && emailMessage.getRetryCount() < maxRetryCount) {
				// LOG.info("Retry count :" + emailMessage.getRetryCount());
				try {
					Message message = new MimeMessage(session);
					message.setFrom(new InternetAddress(username));
					if (emailMessage.getCustomerEmail().contains(";")) {
						String[] emailAddresses = emailMessage.getCustomerEmail().split(";");
						lstAddresses = new ArrayList<InternetAddress>();
						for (int i = 0; i < emailAddresses.length; i++) {
							if (emailAddresses[i].trim().length() > 0)
								lstAddresses.add(new InternetAddress(emailAddresses[i]));
						}
						message.addRecipients(Message.RecipientType.TO, lstAddresses.toArray(new InternetAddress[] {}));
					} else {
						message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailMessage.getCustomerEmail()));
					}
					message.setSubject(emailMessage.getSubject());

					message.setContent(contents, "text/html; charset=\"utf-8\"");
					Transport.send(message);
					emailSent = true;
				} catch (Exception e) {
					e.printStackTrace();
					// LOG.info("Exception in sendEmail method after sending
					// email 3 times" + e);
				}
				// Email not Sent
				if (emailSent == false && maxRetryCount != 0 && emailMessage.getRetryCount() <= maxRetryCount) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setRetryCount(emailMessage.getRetryCount() + 1);
				}
				// Email Sent
				if (emailSent == true) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setDeliveredOn(new java.sql.Timestamp(new java.util.Date().getTime()));

				}
			} // end of while
		} catch (Exception e) {
			// LOG.error("GOT Exception in class EmailUtil : sendEmail()---",
			// e);
			// throw new EnterpriseBaseException(ErrorName.COULD_NOT_SEND_MAIL);
		} finally {
			lstAddresses = null;
		}
		// LOG.info("EmailUtils: sendEmail method END");
		return emailSent;
	}

/*	public static boolean sendEmail(HospitalEmailSettingDto hospitalEmailSetting,EmailMessage emailMessage, String email, String subject, String contents) {
		// LOG.info("EmailUtils: sendEmail method STARTS");
		Integer maxRetryCount = 3;// MessageAttributeConstants.MAX_REDELIVERYCOUNT;

		// LOG.info("After cachedata");
		final String username = hospitalEmailSetting.getEmailId();//PropertyHandler.getProperty(siteId+".spin.serivce.email.email");// emailSetings.getEmail_id();//emailConfig.getSmtpUserName();
		final String password = hospitalEmailSetting.getPassword();//PropertyHandler.getProperty(siteId+".spin.serivce.email.password");// emailSetings.getPassword();//emailConfig.getSmtpUserPassword();

		boolean emailSent = false;
		List<InternetAddress> lstAddresses = null;
		try {
			Properties props = new Properties();
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");//PropertyHandler.getProperty(siteId+".spin.serivce.email.host"));
			props.put("mail.smtp.port", hospitalEmailSetting.getPort().toString());//PropertyHandler.getProperty(siteId+".spin.serivce.email.port"));
			props.put("mail.smtp.timeout", "60000");
			props.put("mail.smtp.connectiontimeout", "60000");
			props.put("mail.smtp.ssl.trust", "*");

			Session session = null;
			if ("true" == null || "true".trim().equalsIgnoreCase("false")) {
				session = Session.getInstance(props);
			} else {
				session = Session.getInstance(props, new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username, password);
					}
				});
			}

			while (emailSent == false && emailMessage.getRetryCount() < maxRetryCount) {
				// LOG.info("Retry count :" + emailMessage.getRetryCount());
				try {
					Message message = new MimeMessage(session);
					message.setFrom(new InternetAddress(username));
					if (email.contains(";")) {
						String[] emailAddresses = email.split(";");
						lstAddresses = new ArrayList<InternetAddress>();
						for (int i = 0; i < emailAddresses.length; i++) {
							if (emailAddresses[i].trim().length() > 0)
								lstAddresses.add(new InternetAddress(emailAddresses[i]));
						}
						message.addRecipients(Message.RecipientType.TO, lstAddresses.toArray(new InternetAddress[] {}));
					} else {
						message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
					}
					message.setSubject(subject);

					message.setContent(contents, "text/html; charset=\"utf-8\"");
					Transport.send(message);
					emailSent = true;
				} catch (Exception e) {
					e.printStackTrace();
					// LOG.info("Exception in sendEmail method after sending
					// email 3 times" + e);
				}
				// Email not Sent
				if (emailSent == false && maxRetryCount != 0 && emailMessage.getRetryCount() <= maxRetryCount) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setRetryCount(emailMessage.getRetryCount() + 1);
				}
				// Email Sent
				if (emailSent == true) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setDeliveredOn(new java.sql.Timestamp(new java.util.Date().getTime()));

				}
			} // end of while
		} catch (Exception e) {
			// LOG.error("GOT Exception in class EmailUtil : sendEmail()---",
			// e);
			// throw new EnterpriseBaseException(ErrorName.COULD_NOT_SEND_MAIL);
		} finally {
			lstAddresses = null;
		}
		// LOG.info("EmailUtils: sendEmail method END");
		return emailSent;
	}
	
	public static boolean sendEmailWithAttachment(HospitalEmailSettingDto hospitalEmailSetting,EmailMessage emailMessage, String email, String subject, String contents,String filePath , String fileName) {
		// LOG.info("EmailUtils: sendEmail method STARTS");
		Integer maxRetryCount = 3;// MessageAttributeConstants.MAX_REDELIVERYCOUNT;

		// LOG.info("After cachedata");
		final String username = hospitalEmailSetting.getEmailId();//PropertyHandler.getProperty(siteId+".spin.serivce.email.email");// emailSetings.getEmail_id();//emailConfig.getSmtpUserName();
		final String password = hospitalEmailSetting.getPassword();//PropertyHandler.getProperty(siteId+".spin.serivce.email.password");// emailSetings.getPassword();//emailConfig.getSmtpUserPassword();

		boolean emailSent = false;
		List<InternetAddress> lstAddresses = null;
		try {
			Properties props = new Properties();
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");//PropertyHandler.getProperty(siteId+".spin.serivce.email.host"));
			props.put("mail.smtp.port", hospitalEmailSetting.getPort().toString());//PropertyHandler.getProperty(siteId+".spin.serivce.email.port"));
			props.put("mail.smtp.timeout", "60000");
			props.put("mail.smtp.connectiontimeout", "60000");
			props.put("mail.smtp.ssl.trust", "*");

			Session session = null;
			if ("true" == null || "true".trim().equalsIgnoreCase("false")) {
				session = Session.getInstance(props);
			} else {
				session = Session.getInstance(props, new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username, password);
					}
				});
			}

			while (emailSent == false && emailMessage.getRetryCount() < maxRetryCount) {
				// LOG.info("Retry count :" + emailMessage.getRetryCount());
				try {
					Message message = new MimeMessage(session);
				
					message.setFrom(new InternetAddress(username));
					if (email.contains(";")) {
						String[] emailAddresses = email.split(";");
						lstAddresses = new ArrayList<InternetAddress>();
						for (int i = 0; i < emailAddresses.length; i++) {
							if (emailAddresses[i].trim().length() > 0)
								lstAddresses.add(new InternetAddress(emailAddresses[i]));
						}
						message.addRecipients(Message.RecipientType.TO, lstAddresses.toArray(new InternetAddress[] {}));
					} else {
						message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
					}
					message.setSubject(subject);

					Multipart multipart = new MimeMultipart();
					BodyPart part1 = new MimeBodyPart();
					part1.setContent(contents, "text/html; charset=\"utf-8\"");
					multipart.addBodyPart(part1);
					
					BodyPart attachment = null;
					attachment = new MimeBodyPart();
					DataSource source = new FileDataSource(filePath+File.separator+fileName);
					attachment.setDataHandler(new DataHandler(source));
					attachment.setFileName(fileName);
					multipart.addBodyPart(attachment);
					
					message.setContent(multipart);
					 
					Transport.send(message);
					emailSent = true;
				} catch (Exception e) {
					e.printStackTrace();
				}
				// Email not Sent
				if (emailSent == false && maxRetryCount != 0 && emailMessage.getRetryCount() <= maxRetryCount) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setRetryCount(emailMessage.getRetryCount() + 1);
				}
				// Email Sent
				if (emailSent == true) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setDeliveredOn(new java.sql.Timestamp(new java.util.Date().getTime()));

				}
			} // end of while
		} catch (Exception e) {
		} finally {
			lstAddresses = null;
		}
		// LOG.info("EmailUtils: sendEmail method END");
		return emailSent;
	}
	
	
	
	public static boolean sendEmailWithMultipleAttachment(HospitalEmailSettingDto hospitalEmailSetting,EmailMessage emailMessage, String email, String subject, String contents,String filePath , List<String> fileNameList) {
		// LOG.info("EmailUtils: sendEmail method STARTS");
		Integer maxRetryCount = 3;// MessageAttributeConstants.MAX_REDELIVERYCOUNT;

		// LOG.info("After cachedata");
		final String username = hospitalEmailSetting.getEmailId();//PropertyHandler.getProperty(siteId+".spin.serivce.email.email");// emailSetings.getEmail_id();//emailConfig.getSmtpUserName();
		final String password = hospitalEmailSetting.getPassword();//PropertyHandler.getProperty(siteId+".spin.serivce.email.password");// emailSetings.getPassword();//emailConfig.getSmtpUserPassword();

		boolean emailSent = false;
		List<InternetAddress> lstAddresses = null;
		try {
			Properties props = new Properties();
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");//PropertyHandler.getProperty(siteId+".spin.serivce.email.host"));
			props.put("mail.smtp.port", hospitalEmailSetting.getPort().toString());//PropertyHandler.getProperty(siteId+".spin.serivce.email.port"));
			props.put("mail.smtp.timeout", "60000");
			props.put("mail.smtp.connectiontimeout", "60000");
			props.put("mail.smtp.ssl.trust", "*");

			Session session = null;
			if ("true" == null || "true".trim().equalsIgnoreCase("false")) {
				session = Session.getInstance(props);
			} else {
				session = Session.getInstance(props, new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username, password);
					}
				});
			}

			while (emailSent == false && emailMessage.getRetryCount() < maxRetryCount) {
				// LOG.info("Retry count :" + emailMessage.getRetryCount());
				try {
					Message message = new MimeMessage(session);
				
					message.setFrom(new InternetAddress(username));
					if (email.contains(";")) {
						String[] emailAddresses = email.split(";");
						lstAddresses = new ArrayList<InternetAddress>();
						for (int i = 0; i < emailAddresses.length; i++) {
							if (emailAddresses[i].trim().length() > 0)
								lstAddresses.add(new InternetAddress(emailAddresses[i]));
						}
						message.addRecipients(Message.RecipientType.TO, lstAddresses.toArray(new InternetAddress[] {}));
					} else {
						message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
					}
					message.setSubject(subject);

					Multipart multipart = new MimeMultipart();
					BodyPart part1 = new MimeBodyPart();
					part1.setContent(contents, "text/html; charset=\"utf-8\"");
					multipart.addBodyPart(part1);
					
					for (String fileName : fileNameList) {
						BodyPart attachment = null;
						attachment = new MimeBodyPart();
						DataSource source = new FileDataSource(filePath+File.separator+fileName);
						attachment.setDataHandler(new DataHandler(source));
						attachment.setFileName(fileName);
						multipart.addBodyPart(attachment);
					}
					
					
					message.setContent(multipart);
					 
					Transport.send(message);
					emailSent = true;
				} catch (Exception e) {
					e.printStackTrace();
				}
				// Email not Sent
				if (emailSent == false && maxRetryCount != 0 && emailMessage.getRetryCount() <= maxRetryCount) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setRetryCount(emailMessage.getRetryCount() + 1);
				}
				// Email Sent
				if (emailSent == true) {
					// LOG.info("email sent : " + emailSent);
					emailMessage.setDeliveredOn(new java.sql.Timestamp(new java.util.Date().getTime()));

				}
			} // end of while
		} catch (Exception e) {
		} finally {
			lstAddresses = null;
		}
		// LOG.info("EmailUtils: sendEmail method END");
		return emailSent;
	}*/
	
	
	
	
	
	public static String getEmailHtmlFile(String htmlPath) {
		StringBuilder html = new StringBuilder();
		BufferedReader in = null;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(htmlPath), "UTF-8"));
			String str;
			while ((str = in.readLine()) != null) {
				html.append(str);
			}
		} catch (IOException e) {
			/*
			 * LOG.error(
			 * "IOException in Class BaseEmailTemplate : getEmailHtmlFile()---",
			 * e);*/
			 
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return html.toString();
	}

	public static void main(String[] args) {

		StringBuilder s = new StringBuilder("Hi i ###1 amol");
		// s = s.replaceAll("###1", "am");
		System.out.println(s);

		
		/* * EmailUtil eu = new EmailUtil(); EmailMessage em= new EmailMessage();
		 * em.setRetryCount(2); String htmlEmailPath="xyz.htm"; String content =
		 * eu.getEmailHtmlFile(htmlEmailPath); //eu.sendEmail(em, "xyz.com",
		 * "Test mail", content);*/
		 
	}

	
}
