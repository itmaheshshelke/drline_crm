/**
Created By: Namrata Malviya
 21-Jan-2019* 
TemplateRepository.java
 */
package ms.sp2.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ms.sp2.test.jpa.Template;

public interface TemplateRepository extends JpaRepository<Template, Integer>{

	@Query("Select t from Template t where t.templateId =:templateId ")
	public Template getTemplateById(@Param("templateId")Integer templateId);

}
