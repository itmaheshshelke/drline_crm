package ms.sp2.test.logic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ms.sp2.test.dao.LoginDao;
import ms.sp2.test.dao.PropertiesDaoImpl;
import ms.sp2.test.dto.EmailMessage;
import ms.sp2.test.dto.EmailPropertiesDto;
import ms.sp2.test.dto.EmployeeDto;
import ms.sp2.test.dto.MessageAttributes;
import ms.sp2.test.dto.UserDetailsDto;
import ms.sp2.test.dto.mapper.EmployeeMapper;
import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.exception.HospitalServiceErrors;
import ms.sp2.test.jpa.Employee;

@Component
public class LoginLogicImpl implements LoginLogic {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(LoginLogicImpl.class);

	@Autowired
	private LoginDao loginDao;
	
	@Autowired
	SmsLogic smsLogic;
	
	@Autowired
	EmailLogic emailLogic;
	
	@Autowired
	PropertiesDaoImpl propertiesDaoImpl;

	@Override
	public EmployeeDto login(UserDetailsDto userDetailsDto) throws HospitalExceptionHandler {
		EmployeeDto employeeDto = new EmployeeDto();

		try {
			employeeDto = loginDao.login(userDetailsDto);
		} catch (HospitalExceptionHandler hwe) {
			throw hwe;
		} catch (Exception e) {
			logger.error("Exception Error in LoginLogicImpl - > login ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDto;
	}

	@Override
	public EmployeeDto sendOtp(String mono, Integer hospitalId) throws HospitalExceptionHandler {
		Boolean result = false;
		EmployeeDto employeeDto = new EmployeeDto();
		Long otp = Math.round(Math.random() * 10000000);
		try {

			Employee employee = loginDao.sendOtp(mono,hospitalId);
			employeeDto = EmployeeMapper._toDto(employee);
			employeeDto.setOtp(otp.toString());
			if (result = true) {
				
				final String otp1 = String.valueOf(otp);
				
					EmailMessage message = new EmailMessage();
					message.setCustomerEmail(employee.getEmailId());
					message.setSubject("Welcome to Doctospek.");
					message.setTemplateName("executive_credentials_template.html.");
					message.setRetryCount(1);

					MessageAttributes[] attributes = new MessageAttributes[2];
					MessageAttributes messageAttributes = new MessageAttributes();
					messageAttributes.setId("###1");
					messageAttributes.setValue(employee.getFirstName());
					attributes[0] = messageAttributes;

					messageAttributes = new MessageAttributes();
					messageAttributes.setId("###2");
					messageAttributes.setValue(otp1);
					attributes[1] = messageAttributes;

					message.setMessageAttributes(attributes);
					// in case of admin use this constructor to build email settings
					EmailPropertiesDto emailPropertiesDto = propertiesDaoImpl.getEmailPropertiesById(1);
			     try {
				     emailLogic.send(message, emailPropertiesDto);
			     } catch (Exception e) {
				 // TODO: handle exception
			     } 

				/*final String mobileNo = mono;
				Template template = smsLogic.getSmsTemplateById(StatusConstants.SEND_OTP);
				Thread t = new Thread(new Runnable() {

					@Override
					public void run() {
						try {

							String content = "";
							content = template.getSmsBody();
							content = content.replaceAll("##1", otp1);
							content = content.replaceAll("##2", "\n");
							smsLogic.sendSms(mobileNo, content, "TRANS", "Debug", template.getTemplateId(), 0);

						} catch (Exception e) {
							System.out.println("Exception while sending SMS to customer " + mobileNo);
						}
					}
				});
				t.start();*/
			}
			return employeeDto;
		} catch (HospitalExceptionHandler hwe) {
			throw hwe;
		} catch (Exception e) {
			logger.error("Exception Error in LoginLogicImpl - > sendOtp ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
	}

	@Override
	public Boolean resetPassword(Integer employeeId, String newPassword) throws HospitalExceptionHandler {
		Boolean result = false;
		try{
			result = loginDao.resetPassword(employeeId,newPassword);
			return result;
		} catch (HospitalExceptionHandler hwe) {
			throw hwe;
		} catch (Exception e) {
			logger.error("Exception Error in LoginLogicImpl - > sendOtp ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
	}

	@Override
	public Boolean saveNewPassword(String oldpasswrd, String newpasswrd, Integer employeeId)
			throws HospitalExceptionHandler {
		Boolean result = false;
		try {
			result = loginDao.saveNewPassword(oldpasswrd,newpasswrd,employeeId);
			return result;
		} catch (HospitalExceptionHandler hwe) {
			throw hwe;
		} catch (Exception e) {
			logger.error("Exception Error in LoginLogicImpl - > sendOtp ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
	}
}