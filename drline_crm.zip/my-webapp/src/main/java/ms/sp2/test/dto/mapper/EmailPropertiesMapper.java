package ms.sp2.test.dto.mapper;

/**

 * created by : Mahesh Shelke
   created on : 22-Jan-2019
 */

import org.modelmapper.ModelMapper;

import ms.sp2.test.dto.EmailPropertiesDto;
import ms.sp2.test.jpa.EmailProperties;

/**
 * created By : Mahesh Shelke
 *
 * created On : 22-Jan-2019
 */
public class EmailPropertiesMapper {
	
	public static EmailPropertiesDto _toDto(EmailProperties emailProperties) {

		ModelMapper mapper = new ModelMapper();
		EmailPropertiesDto dtoObject = mapper.map(emailProperties, EmailPropertiesDto.class);
		return dtoObject;
	}

	public static EmailProperties _toJpa(EmailPropertiesDto emailPropertiesDto) {

		ModelMapper mapper = new ModelMapper();
		EmailProperties jpaObject = mapper.map(emailPropertiesDto, EmailProperties.class);
		return jpaObject;
	}
}
