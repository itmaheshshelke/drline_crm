package ms.sp2.test.logic;

import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.jpa.Template;

public interface SmsLogic {

	public String sendSms(String mobileNo, String message, String route, String mode,int templateId, Integer hospitalId) throws HospitalExceptionHandler;
	
	/*public String sendOtp(String mobileNo, int siteId) throws HelthwellExceptionHandler;

	public String getBalance(int siteId) throws HelthwellExceptionHandler;*/
	
	public Template getSmsTemplateById(Integer templateId) throws HospitalExceptionHandler;

	/*public String getDeleveryReport(String mobileNo, String messageId,int siteId) throws HelthwellExceptionHandler;
	
	public Boolean sendEmail(EmailMessage emailMessage, String email, String subject, String contents, Integer hospitalId)throws HelthwellExceptionHandler;
*/
	}
