package ms.sp2.test.dto;

import java.io.Serializable;

public class SmsProviderSettingDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer smsProviderSettingId;
	
	private String providerName;
	
	private String baseUrl;
	
	private String userName;
	
	private String password;
	
	private String senderId;

	
	
	
	
	public Integer getSmsProviderSettingId() {
		return smsProviderSettingId;
	}

	public void setSmsProviderSettingId(Integer smsProviderSettingId) {
		this.smsProviderSettingId = smsProviderSettingId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}
	

	
	

}
