package ms.sp2.test.jpa;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * created By : Mahesh Shelke
 *
 * created On : 19-Jan-2019
 */
@Entity
@Table(name="email_properties")
public class EmailProperties implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="email_properties_id")
	private Integer emailPropertiesId;
	
	@Column(name="template_url")
	private String templateUrl;
	
	@Column(name="email_id")
	private String emailId;
	
	@Column(name="host")
	private String host;
	
	@Column(name="port")
	private String port;
	
	@Column(name="password")
	private String password;

	
	public Integer getEmailPropertiesId() {
		return emailPropertiesId;
	}

	public void setEmailPropertiesId(Integer emailPropertiesId) {
		this.emailPropertiesId = emailPropertiesId;
	}

	public String getTemplateUrl() {
		return templateUrl;
	}

	public void setTemplateUrl(String templateUrl) {
		this.templateUrl = templateUrl;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
