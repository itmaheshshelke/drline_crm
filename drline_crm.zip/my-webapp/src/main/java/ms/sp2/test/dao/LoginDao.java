package ms.sp2.test.dao;

import ms.sp2.test.dto.EmployeeDto;
import ms.sp2.test.dto.UserDetailsDto;
import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.jpa.EmailInbox;
import ms.sp2.test.jpa.Employee;

public interface LoginDao {

	EmployeeDto login(UserDetailsDto userDetailsDto)throws HospitalExceptionHandler ;

	Employee sendOtp(String mono, Integer hospitalId) throws HospitalExceptionHandler;

	Boolean resetPassword(Integer employeeId, String newPassword) throws HospitalExceptionHandler;

	Boolean saveNewPassword(String oldpasswrd, String newpasswrd, Integer employeeId) throws HospitalExceptionHandler;

	
	public Boolean saveEmail(EmailInbox emailInbox)throws HospitalExceptionHandler;
}
