package ms.sp2.test.logic;

import ms.sp2.test.dto.EmployeeDto;
import ms.sp2.test.dto.UserDetailsDto;
import ms.sp2.test.exception.HospitalExceptionHandler;

public interface LoginLogic {

	EmployeeDto login(UserDetailsDto userDetailsDto)throws HospitalExceptionHandler;

	EmployeeDto sendOtp(String mono, Integer hospitalId) throws HospitalExceptionHandler;

	Boolean resetPassword(Integer employeeId, String newPassword) throws HospitalExceptionHandler;

	Boolean saveNewPassword(String oldpasswrd, String newpasswrd, Integer employeeId) throws HospitalExceptionHandler;


}
