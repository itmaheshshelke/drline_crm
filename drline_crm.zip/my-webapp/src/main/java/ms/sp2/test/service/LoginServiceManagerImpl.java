package ms.sp2.test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ms.sp2.test.dto.EmployeeDto;
import ms.sp2.test.dto.UserDetailsDto;
import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.exception.HospitalServiceErrors;
import ms.sp2.test.logic.LoginLogic;

@Service
public class LoginServiceManagerImpl implements LoginServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(LoginServiceManagerImpl.class);

	@Autowired
	private LoginLogic loginLogic;

	@Override
	public EmployeeDto login(UserDetailsDto userDetailsDto) throws HospitalExceptionHandler {
		EmployeeDto employeeDto = new EmployeeDto();
		try {
			employeeDto = loginLogic.login(userDetailsDto);
		} catch (HospitalExceptionHandler hwe) {
			throw hwe;
		} catch (Exception e) {
			logger.error("Exception Error in LoginServiceManagerImpl - > login ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDto;
	}

	@Override
	public EmployeeDto sendOtp(String mono, Integer hospitalId) throws HospitalExceptionHandler {
		EmployeeDto employeeDto = new EmployeeDto();
		try {
			employeeDto = loginLogic.sendOtp(mono,hospitalId);
		}catch(HospitalExceptionHandler hwe) {
			throw hwe;
		}catch(Exception e) {
			logger.error("Exception Error in LoginServiceManagerImpl - > sendOtp ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDto;
	}

	@Override
	public Boolean resetPassword(Integer employeeId, String newPassword) throws HospitalExceptionHandler {
		Boolean result = false;
		try {
			result = loginLogic.resetPassword(employeeId,newPassword);
			return result;
		}catch(HospitalExceptionHandler hwe) {
			throw hwe;
		}catch(Exception e) {
			logger.error("Exception Error in LoginServiceManagerImpl - > resetPassword ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
		
}

	@Override
	public Boolean saveNewPassword(String oldpasswrd, String newpasswrd, Integer employeeId)
			throws HospitalExceptionHandler {
		Boolean result = false;
		try {
			result = loginLogic.saveNewPassword(oldpasswrd,newpasswrd,employeeId);
			return result;
		}catch(HospitalExceptionHandler hwe) {
			throw hwe;
		}catch(Exception e) {
			logger.error("Exception Error in LoginServiceManagerImpl - > saveNewPassword ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
	}
	
	
	
}