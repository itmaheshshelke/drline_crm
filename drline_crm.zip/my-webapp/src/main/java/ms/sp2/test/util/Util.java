package ms.sp2.test.util;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;



public class Util {

	public static String getUniqueToken() {
		/*
		 * UUID idOne = UUID.randomUUID();
		 * 
		 * return idOne.toString().replaceAll("-", "");
		 */
		Random r = new Random();
		String number = String.valueOf((1000 + r.nextInt(9000)));
		long millis = System.currentTimeMillis();
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(millis);
		return (number + c.get(Calendar.SECOND) + c.get(Calendar.MILLISECOND));
	}
	
	public static String generatePIN() {
		List<Integer> numbers = new ArrayList<Integer>();
		for (int i = 0; i < 10; i++) {
			numbers.add(i);
		}
		Collections.shuffle(numbers);
		String result = "";
		for (int i = 0; i < 6; i++) {
			result += numbers.get(i).toString();
		}
		return result;
	}
	
	public static String roundTwoDecimal(String amount) {
		Float floatAmt = Float.parseFloat(amount);
		DecimalFormat df = new DecimalFormat("#0.00");
		df.setMaximumFractionDigits(2);
		amount = df.format(floatAmt);
		return amount;
	}
	
	public static String generateSalt() {
		String saltString = null;

		try {

			// Generate Random Salt
			org.jasypt.salt.RandomSaltGenerator rg = new org.jasypt.salt.RandomSaltGenerator();

			saltString = org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64
					.encodeBase64(rg.generateSalt(8)).toString();
			// return new
			// String(org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64.encodeBase64(rg.generateSalt(8)));

		} catch (Exception e) {
		}
		return saltString;
	}
	
	public static String generatePassword(String salt,
			String userEnteredPasswordInClearText) {

		String generatedPassword = null;
		MessageDigest sha256 = null;
		try {
			// Create SHA-256 hashing...
			sha256 = MessageDigest.getInstance("SHA-256");
			// Concat password and salt
			byte[] passBytes = (salt.concat(userEnteredPasswordInClearText))
					.getBytes();
			// Hash both
			byte[] passHash = sha256.digest(passBytes);
			String hashedPassword = new String(
					org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64
							.encodeBase64(passHash));
			// / This should go in database as a hashed password
			generatedPassword = new String(hashedPassword);

		} catch (Exception e) {
		} finally {
			sha256 = null;
		}

		return generatedPassword;
	}
	
	public static boolean verifyPassword(String saltInDatabase,
			String passwordInDatabase, String userEnteredPasswordInClearText) {

		boolean isValidUser = false;
		try {
			String generatedPassword = generatePassword(saltInDatabase,
					userEnteredPasswordInClearText);
			if (generatedPassword.equals(passwordInDatabase)) {
				// System.out.println("Password Matched!");
				isValidUser = true;
			} else if (!generatedPassword.equals(passwordInDatabase)) {
				// System.out.println("Password Not Matched!");
				isValidUser = false;
			}

		} catch (Exception e) {
		}

		return isValidUser;
	}
	
	public static String encodeImage(byte[] imageByteArray) {
		  return Base64.encodeBase64URLSafeString(imageByteArray);
		 }

		 public static byte[] decodeImage(String imageDataString) {
		  return Base64.decodeBase64(imageDataString);
		 }
		 
		 public static void main(String[] args) {
			 //System.out.println(Util.generatePIN());
			// System.out.println(Util.generatePassword(Util.generateSalt(),"Amol"));
			 System.out.println(Util.generatePassword("[B@1d9a3be", "ez/h92VWNG/SmEerXnZvXW8XvmNP+qIkmkKInL6yvZk="));
		 }
		 
		 
		 public static List<Date> getLastthirtydaysfromtoday(){
				Date  date=new Date();
				List<Date> dateList=new ArrayList<>();
		    	String incDate;
		    	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		    	Calendar c = Calendar.getInstance();
		    	c.setTime(date);
		    	c.add(Calendar.MONTH, -2);
		    	int maxDay = c.getActualMaximum(Calendar.DAY_OF_MONTH);
		    	maxDay=maxDay+31;
		    	for(int co=maxDay; co>=0; co--){
		    	    c.add(Calendar.DATE, 1); 
		    	    incDate = sdf.format(c.getTime());
		    	    System.out.println(incDate);
		    	    dateList.add(c.getTime());
		    	    if(co==0)
		    	    	break;
		    	}
		    	Collections.sort(dateList, (o1, o2) -> o2.compareTo(o1));
		    	return dateList;
			}
		 
		 //remove duplicate date in date list;
		 
	
	public static List<Date> removeDuplicateElement(List<Date> dateTempList) throws ParseException {
		List<Date> allEvents = dateTempList;
		List<Date> noRepeatList = new ArrayList<Date>();
		
		for (Date event : allEvents) {
			Date pickDate = new SimpleDateFormat("yyyy-MM-dd").parse(event.toString());
			boolean isFound = false;
			// check if the event name exists in noRepeat
			for (Date e : noRepeatList) {
				Date pickDate1 = new SimpleDateFormat("yyyy-MM-dd").parse(e.toString());
				if (pickDate1.equals(pickDate)) {
					isFound = true;
					break;
				}
			}
			if (!isFound)
				noRepeatList.add(event);
		}
		return noRepeatList;
	}
	
	
/*	public static List<BranchAllocationDto> removeDuplicateElementById(List<BranchAllocationDto> dateTempList)
			throws ParseException {
		List<BranchAllocationDto> noRepeatList = new ArrayList<BranchAllocationDto>();
		for (BranchAllocationDto event : dateTempList) {
			boolean isFound = false;
			for (BranchAllocationDto e : noRepeatList) {
				if (e.getBranchId() == event.getBranchId()) {
					isFound = true;
					break;
				}
			}
			if (!isFound)
				noRepeatList.add(event);
		}
		return noRepeatList;
	}*/
	
	// resize image
	public static BufferedImage resizeImage(final Image image, int width, int height) {
        final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        final Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setComposite(AlphaComposite.Src);
        //below three lines are for RenderingHints for better image quality at cost of higher processing time
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.drawImage(image, 0, 0, width, height, null);
        graphics2D.dispose();
        return bufferedImage;
    }
	
	
}
