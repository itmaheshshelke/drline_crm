package ms.sp2.test.logic;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import ms.sp2.test.constants.EmailConstant;
import ms.sp2.test.dao.LoginDao;
import ms.sp2.test.dto.EmailMessage;
import ms.sp2.test.dto.EmailPropertiesDto;
import ms.sp2.test.dto.MessageAttributes;
import ms.sp2.test.jpa.EmailInbox;
import ms.sp2.test.util.EmailUtil;
@Component
@Transactional
public class EmailLogicImpl implements EmailLogic {

	Logger logger = LoggerFactory.getLogger(EmailLogicImpl.class);
	
	@Autowired
	private LoginDao loginDao;
	
	
	@Async
	@Override
	public void send(EmailMessage message, EmailPropertiesDto emailPropertiesDto) {
		EmailInbox emailInbox = new EmailInbox();
		try {
			// build email template ..
			String templateUrlInner = "";

			final String EMAIL_TEMPLATE = "hospital_templates";
			// String templateUrl = System.getProperty("user.dir");
			if(message.getTemplatePath()!=null) {
				templateUrlInner = message.getTemplatePath();
			}else {
			templateUrlInner = emailPropertiesDto.getTemplateUrl()  +EMAIL_TEMPLATE+"\\"+ message.getTemplateName();
			}
			final String htmlEmailPath = templateUrlInner;

			Thread t = new Thread(new Runnable() {

				@Override
				public void run() {

					try {
						System.out.println(htmlEmailPath);
						Boolean result = false;
						String content = EmailUtil.getEmailHtmlFile(htmlEmailPath);

						// expected to send attributes in sequential manner ...
						for (MessageAttributes attributes : message.getMessageAttributes()) {
							content = content.replaceAll(attributes.getId(), attributes.getValue());
						}

						result = EmailUtil.sendEmail(emailPropertiesDto, message, content);
						Integer transactionNumber = (int) Math.round(Math.random() * 100000);
						emailInbox.setEmailTransactionId(transactionNumber);
						emailInbox.setEmailTemplateType(message.getSubject());
						emailInbox.setService(EmailConstant.TRANS);
						if (result == true) {
							emailInbox.setStatus(EmailConstant.SENT);
						} else {
							emailInbox.setStatus(EmailConstant.FAILED);
						}
						loginDao.saveEmail(emailInbox);
						//hospitalEmailSettingDao.saveEmail(emailInbox);
						logger.info("Email Sent Sucessfully.");
					} catch (Exception e) {
						logger.error("Exception while sending EMAIL to {} ", message.getCustomerEmail());
					}

				}
			});
			t.start();

		} catch (HibernateException he) {
			logger.error("HibernateException Error in HospitalEmailSettingLogicImpl - > sendEmail ", he);
			// throw new
			// HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in HospitalEmailSettingLogicImpl - > sendEmail ", e);
			// throw new
			// HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		// return result;
	}

}
