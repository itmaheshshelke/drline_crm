/**
Created By: Namrata Malviya
 21-Jan-2019* 
SmsProviderSettingRepository.java
 */
package ms.sp2.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ms.sp2.test.jpa.SmsProviderSetting;

public interface SmsProviderSettingRepository extends JpaRepository<SmsProviderSetting, Integer>{

	@Query("Select s from SmsProviderSetting s where s.smsProviderSettingId =:smsProviderSettingId ")
	public SmsProviderSetting getSmsPropertiesById(@Param("smsProviderSettingId")Integer smsProviderSettingId);
}
