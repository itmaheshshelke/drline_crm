package ms.sp2.test.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.exception.HospitalServiceErrors;
import ms.sp2.test.jpa.SmsProviderSetting;

public class SMSUtil {

	public static String sendSms(SmsProviderSetting smsConfig, String mobileNo, String message, String service , int templateId)
			throws HospitalExceptionHandler {
		String result = "";
		try {
			StringBuilder sb = new StringBuilder(smsConfig.getBaseUrl());
			sb.append("user_name=");
			sb.append(smsConfig.getUserName());
			sb.append("&password=");
			sb.append(smsConfig.getPassword());
			sb.append("&sender_id=");
			sb.append(smsConfig.getSenderId());
			sb.append("&service=");
			sb.append(service);
			sb.append("&mobile_no=");
			sb.append(mobileNo);
			sb.append("&message=");
			sb.append(URLEncoder.encode(message, "UTF-8"));
			sb.append("&method=send_sms");
			URL obj = new URL(sb.toString().replace(" ", ""));
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("GET");
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			result = response.toString();
		} catch (Exception e) {
			throw new HospitalExceptionHandler(HospitalServiceErrors.SMS_SENDING_FAIL);
		}

		return result;
	}

	public static String getBalance(SmsProviderSetting smsConfig) throws HospitalExceptionHandler {
		StringBuffer response = new StringBuffer();
		// https://aikonsms.co.in/control/smsapi.php?user_name=henx&password=HenxServer@17&method=get_balance
		try {
			StringBuilder sb = new StringBuilder(smsConfig.getBaseUrl());
			sb.append("user_name=");
			sb.append(smsConfig.getUserName());
			sb.append("&password=");
			sb.append(smsConfig.getPassword());
			// sb.append("&service=" + service);
			sb.append("&method=get_balance");
			URL obj = new URL(sb.toString().replace(" ", ""));
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			con.getResponseCode();
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		} catch (Exception e) {
			throw new HospitalExceptionHandler(HospitalServiceErrors.SMS_BALANCE_FEATCHING_FAIL);
		}
		return response.toString();
	}

	public static String deleveryReport(SmsProviderSetting smsConfig, String messageId) throws HospitalExceptionHandler {
		StringBuffer response = new StringBuffer();
		try {
			StringBuilder sb = new StringBuilder(smsConfig.getBaseUrl());
			sb.append("user_name=");
			sb.append(smsConfig.getUserName());
			sb.append("&password=");
			sb.append(smsConfig.getPassword());
			sb.append("&transaction_id=" + messageId);
			sb.append("&method=get_status");
			URL obj = new URL(sb.toString().replace(" ", ""));
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			con.getResponseCode();
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		} catch (Exception e) {
			throw new HospitalExceptionHandler(HospitalServiceErrors.SMS_DELIVERY_REPORT_FEATCHING_FAIL);
		}
		return response.toString();
	}
	

}
