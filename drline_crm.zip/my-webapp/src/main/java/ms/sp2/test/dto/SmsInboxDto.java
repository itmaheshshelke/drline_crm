package ms.sp2.test.dto;

import java.io.Serializable;

public class SmsInboxDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer smsInboxId;
	
	private String smsTemplateType;
	
	private Integer hospitalId;
	
	private String smsTransactionId;
	
	private String service;
	
	private Integer status;
	

	public Integer getSmsInboxId() {
		return smsInboxId;
	}

	public void setSmsInboxId(Integer smsInboxId) {
		this.smsInboxId = smsInboxId;
	}

	public String getSmsTemplateType() {
		return smsTemplateType;
	}

	public void setSmsTemplateType(String smsTemplateType) {
		this.smsTemplateType = smsTemplateType;
	}

	public Integer gethospitalId() {
		return hospitalId;
	}

	public void sethospitalId(Integer hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getSmsTransactionId() {
		return smsTransactionId;
	}

	public void setSmsTransactionId(String smsTransactionId) {
		this.smsTransactionId = smsTransactionId;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
	

}
