package ms.sp2.test.dto;


import java.io.Serializable;


/**
 * created By : Mahesh Shelke
 *
 * created On : 19-Jan-2019
 */

public class EmailPropertiesDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer emailPropertiesId;
	
	private String templateUrl;
	
	private String emailId;
	
	private String host;
	
	private String port;
	
	private String password;

	public Integer getEmailPropertiesId() {
		return emailPropertiesId;
	}

	public void setEmailPropertiesId(Integer emailPropertiesId) {
		this.emailPropertiesId = emailPropertiesId;
	}

	public String getTemplateUrl() {
		return templateUrl;
	}

	public void setTemplateUrl(String templateUrl) {
		this.templateUrl = templateUrl;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
