package ms.sp2.test.exception;

public class HospitalExceptionHandler extends Exception {

	private static final long serialVersionUID = 1L;

	public static final HospitalServiceErrors GENERIC_EXCEPTION_HIBERNATE = null;

	private String errorCode;
	
	private HospitalServiceErrors errorName;

	private String description;

	/**
	 * @return the errorName
	 */
	public HospitalServiceErrors getErrorName() {
		return errorName;
	}

	/**
	 * @param errorName
	 *            the errorName to set
	 */
	public void setErrorName(HospitalServiceErrors errorName) {
		this.errorName = errorName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Instantiates a new NGOP base exception.
	 * 
	 * @param errorCode
	 *            the error code
	 * @param flowName
	 *            the flow name
	 * @param cause
	 *            the cause
	 */
	public HospitalExceptionHandler(HospitalServiceErrors errorName) {
		super(errorName.getErrorCode(), new Throwable(
				errorName.getErrorDescription()));
		this.errorCode = errorName.getErrorCode();
		this.errorName = errorName;
		this.description = errorName.getErrorDescription();
	}

	public HospitalExceptionHandler(HospitalServiceErrors errorName, String description) {
		super(errorName.getErrorCode(), new Throwable(description));
		this.errorName = errorName;
		this.description = description;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
