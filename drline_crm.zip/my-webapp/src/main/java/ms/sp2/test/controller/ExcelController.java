/**
 * created by : Mahesh Shelke
   created on : 29-Jan-2019
 */
package ms.sp2.test.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ms.sp2.test.dao.PropertiesDao;
import ms.sp2.test.dto.EmailMessage;
import ms.sp2.test.dto.EmailPropertiesDto;
import ms.sp2.test.dto.ExcelDto;
import ms.sp2.test.dto.MessageAttributes;
import ms.sp2.test.jpa.Excel;
import ms.sp2.test.jpa.Template;
import ms.sp2.test.logic.EmailLogic;
import ms.sp2.test.logic.SmsLogic;
import ms.sp2.test.repository.ExcelRepository;
import ms.sp2.test.util.ExcelReader;

/**
 * created By : Mahesh Shelke
 *
 * created On : 29-Jan-2019
 */
@Controller
@RequestMapping("/excel-api")
public class ExcelController {

	@Value("${portal.url}")
	private String portalUrl;

	@Value("${doc.path}")
	private String path;

	@Autowired
	private ExcelRepository excelRepository;

	@Autowired
	private EmailLogic emailLogic;

	@Autowired
	private SmsLogic smsLogic;

	@Autowired
	private PropertiesDao propertiesDao;

	@RequestMapping("/show-excel-upload-page")
	public ModelAndView openExcelUploadPage(HttpServletRequest request, HttpServletResponse response,
			Model modelRedirect) {
		ModelAndView model = new ModelAndView("show-excel");
		try {
			List<Excel> excelList = excelRepository.getAll();

			model.addObject("excelList", excelList);

		} catch (Exception e) {
			// TODO: handle exception
		}
		model.addObject("successMessage", modelRedirect.asMap().get("successMessage"));
		model.addObject("errorMessage", modelRedirect.asMap().get("errorMessage"));
		return model;

	}

	@RequestMapping(value = "/upload-excel", method = RequestMethod.POST)
	public ModelAndView uploadExcel(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute ExcelDto excelDto, RedirectAttributes attribute) {

		MultipartFile file = excelDto.getFile();

		if (null != file && !file.isEmpty()) {
			try {
				// String filePath = getServletContext().getRealPath("/");
				byte[] bytes = file.getBytes();
				String filename = file.getOriginalFilename();
				String extension = filename.split(Pattern.quote("."))[1];
				excelDto.setData(bytes);
				excelDto.setExtension(extension);

				String fileUploadPath = path;//

				if (null != excelDto.getData()) {
					File file1 = new File(fileUploadPath + File.separator + File.separator + "user_data");
					if (!file1.exists()) {
						if (file1.mkdirs()) {
							System.out.print("Directory is created!");
						} else {
							System.out.print("Failed to create directory!");
						}
					}

					String filePath = file1 + File.separator + file1.getName() + "." + excelDto.getExtension();
					File serverFile = new File(filePath);
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
					stream.write(excelDto.getData());
					stream.flush();
					stream.close();

					List<Excel> userList = ExcelReader.excelData(filePath);
					if (userList != null && !userList.isEmpty()) {
						excelRepository.saveAll(userList);
					}
					attribute.addFlashAttribute("successMessage", "Excel uploaded successfully.");
				}

			} catch (Exception e) {
				attribute.addFlashAttribute("errorMessage", "Error while saving record.");
			}
		}

		return new ModelAndView("redirect:" + "/excel-api/show-excel-upload-page");

	}

	@RequestMapping(value = "/upload-email-template", method = RequestMethod.POST)
	public ModelAndView uploadEmailTemplate(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute ExcelDto excelDto, RedirectAttributes attribute) {
		MultipartFile file = excelDto.getEmailTemplate();
		String[] emailUser = request.getParameterValues("sendEmail");
		String[] smsUser = request.getParameterValues("sendSms");
		if (null != file && !file.isEmpty() && emailUser != null) {
			try {
				// String filePath = getServletContext().getRealPath("/");
				byte[] bytes = file.getBytes();
				String filename = file.getOriginalFilename();
				String extension = filename.split(Pattern.quote("."))[1];
				excelDto.setData(bytes);
				excelDto.setExtension(extension);
				String fileUploadPath = path;//
				if (null != excelDto.getData()) {
					File file1 = new File(fileUploadPath + File.separator + File.separator + "user_data");
					if (!file1.exists()) {
						if (file1.mkdirs()) {
							System.out.print("Directory is created!");
						} else {
							System.out.print("Failed to create directory!");
						}
					}
					String filePath = file1 + File.separator + file1.getName() + "." + excelDto.getExtension();
					File serverFile = new File(filePath);
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
					stream.write(excelDto.getData());
					stream.flush();
					stream.close();

					try {

						if (emailUser != null) {
							for (String employeeId : smsUser) {
								Excel employee = null;
								try {
									employee = excelRepository.getUserDataById(Integer.parseInt(employeeId));
									EmailMessage message = new EmailMessage();
									message.setCustomerEmail(employee.getEmailId());
									message.setSubject("Welcome to Drline");
									message.setRetryCount(1);

									MessageAttributes[] attributes = new MessageAttributes[2];
									MessageAttributes messageAttributes = new MessageAttributes();
									messageAttributes.setId("###1");
									messageAttributes.setValue(employee.getFirstName());
									attributes[0] = messageAttributes;

									messageAttributes = new MessageAttributes();
									messageAttributes.setId("###2");
									messageAttributes.setValue("");
									attributes[1] = messageAttributes;

									message.setMessageAttributes(attributes);
									message.setTemplatePath(filePath);
									// in case of admin use this constructor to build email settings
									EmailPropertiesDto emailPropertiesDto = propertiesDao.getEmailPropertiesById(1);
									emailLogic.send(message, emailPropertiesDto);

								} catch (Exception e) {
									System.out.println(
											"Error while sending email on this email id=" + employee.getEmailId());
								}
							}
							attribute.addFlashAttribute("successMessage", "Email sent successfully.");
						}

					} catch (Exception e) {
						attribute.addFlashAttribute("errorMessage", "Error " + e);
					}
				}
			} catch (Exception e) {
				attribute.addFlashAttribute("errorMessage", "Error while reading excel sheet.");
			}
		}else if((null == file || file.isEmpty()) && emailUser != null) {
			attribute.addFlashAttribute("errorMessage", "Error while reading excel sheet.");
		}
		try {
			if (smsUser != null) {
				for (String employeeId : smsUser) {
					try {
						Excel employee = excelRepository.getUserDataById(Integer.parseInt(employeeId));

						Thread t = new Thread(new Runnable() {
							@Override
							public void run() {
								try {
									
									String content =excelDto.getSmsContent();
									content = content.replaceAll("Dear", employee.getFirstName());
									// content = content.replaceAll("##9", "\n"); now sent sms from our side
									smsLogic.sendSms(employee.getContactNo(), content, "TRANS", "Debug", 1, 0);
								} catch (Exception e) {
									System.out.println(
											"Exception while sending SMS to customer " + employee.getContactNo());
								}
							}
						});
						t.start();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
				attribute.addFlashAttribute("successMessage", "SMS sent successfully");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(emailUser==null && emailUser==null) {
			attribute.addFlashAttribute("errorMessage", "please select any option sms or email.");
		}
		return new ModelAndView("redirect:" + "/excel-api/show-excel-upload-page");
	}

	@RequestMapping(value = "/edit-user-record", method = RequestMethod.GET)
	public ModelAndView getRoleById(@RequestParam Integer employeeId) {
		ModelAndView model = new ModelAndView();
		Excel excel = new Excel();
		try {
			excel = excelRepository.getUserDataById(employeeId);

		} catch (Exception e) {
		}
		model.addObject("excel", excel);
		model.setViewName("edit-user-record");
		return model;
	}

	@RequestMapping(value = "/update-user-data", method = RequestMethod.POST)
	public ModelAndView saveRole(@ModelAttribute("excel") Excel excel, RedirectAttributes attribute,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView("show-excel");
		try {
			excel.setUpdatedBy(1);
			excel.setUpdatedOn(new Date());
			excel.setDelFlag('N');
			excelRepository.save(excel);
			excelRepository.flush();

		} catch (Exception e) {
		}
		model.addObject("successMessage", "Record updated successfully");
		List<Excel> excelList = excelRepository.getAll();
		model.addObject("excelList", excelList);
		return model;
	}

	@RequestMapping(value = "/delete-user-data/{employeeId}", method = RequestMethod.GET)
	public ModelAndView deleteRole(@PathVariable("employeeId") Integer employeeId, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes attribute) {
		ModelAndView model = new ModelAndView("show-excel");
		try {
			Excel excel = excelRepository.getUserDataById(employeeId);
			excel.setUpdatedBy(1);
			excel.setUpdatedOn(new Date());
			excel.setDelFlag('Y');
			excelRepository.save(excel);
			excelRepository.flush();
		} catch (Exception e) {
		}
		model.addObject("successMessage", "Record deleted successfully");
		List<Excel> excelList = excelRepository.getAll();
		model.addObject("excelList", excelList);
		return model;
	}

}
