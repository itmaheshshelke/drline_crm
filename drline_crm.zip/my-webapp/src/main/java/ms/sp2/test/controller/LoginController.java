/**
 * 
 */
package ms.sp2.test.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ms.sp2.test.constants.FlowData;
import ms.sp2.test.constants.WebAppConstants;
import ms.sp2.test.dto.EmployeeDto;
import ms.sp2.test.dto.UserDetailsDto;
import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.service.LoginServiceManager;

/**
 * Created By:- Mahesh Shelke
 * Created On :- Dec 7, 2018 :  3:46:01 PM
 * File Name:- LoginController.java
 *
 */
@RestController
@RequestMapping("/")
public class LoginController extends BaseController{

	@Value("${portal.url}")
	private String portalUrl;
	
	@Autowired
	private LoginServiceManager loginServiceManager;
	
	@RequestMapping("/")
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model=new ModelAndView("login");
		model.addObject("userDetailsDto", new UserDetailsDto());
		return model;
		
	}
	
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public ModelAndView dashboardGet(HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes attribute) {
		ModelAndView mv = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (flowData.isLoggedIn()) {
			return new ModelAndView("redirect:" + portalUrl + "redirect-dashboard");
		} else {
			UserDetailsDto userDetailsDto = new UserDetailsDto();
			mv.addObject("userDetailsDto", userDetailsDto);
			mv.setViewName("login");
			return mv;
		}
	}
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.POST)
	public ModelAndView demo(@ModelAttribute("userDetailsDto") UserDetailsDto userDetailsDto,
			HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws HospitalExceptionHandler {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("dashbord");
		EmployeeDto employeeDto = new EmployeeDto();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			employeeDto = loginServiceManager.login(userDetailsDto);
			if (employeeDto != null) {
				flowData.setSessionDataObject("employeeDto", employeeDto);
				flowData.setSessionDataObject(WebAppConstants.EMPLOYEEID, employeeDto.getEmployeeId());
				flowData.setSessionDataObject(WebAppConstants.EMPFIRSTNAME, employeeDto.getFirstName());
				flowData.setSessionDataObject(WebAppConstants.ROLEID, employeeDto.getRoleId());
			}
			flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
			logger.info("loggedIn succefully........");
		} catch (HospitalExceptionHandler e) {
			logger.error("Error in LoginController- > dashboard", e);
			mv.addObject(WebAppConstants.ERROR_CODE, e.getErrorCode());
			mv.addObject(WebAppConstants.ERROR_MESSAGE, e.getDescription());
			mv.addObject("userDetailsDto", new UserDetailsDto());
			mv.setViewName("login");
		} catch (Exception e) {
			logger.error("Error in LoginController- > dashboard", e);
			mv.addObject("massage", "Please enter valid username or password");
			mv.addObject("userDetailsDto", new UserDetailsDto());
			mv.setViewName("login");
		}
		mv.addObject("employeeDto", employeeDto);
		return mv;
	}
	
	@RequestMapping(value = "/redirect-dashboard", method = RequestMethod.GET)
	public ModelAndView cancel(HttpServletRequest request, HttpServletResponse response, Model modelRedirect)
			throws HospitalExceptionHandler {
		ModelAndView model = new ModelAndView();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		try {
			EmployeeDto employeeDto = (EmployeeDto) flowData.getSessionDataObject("employeeDto");
			Integer employeeId = employeeDto.getEmployeeId();

			employeeDto.setEmployeeId(employeeId);
			model.addObject("employeeDto", employeeDto);
		} catch (Exception e) {
			logger.error("Error in LoginController- > changePassword", e);
			model.setViewName("login");
			model.addObject("userDetailsDto", new UserDetailsDto());
		}
		model.addObject("sucessMessage", modelRedirect.asMap().get("sucessMessage"));
		model.setViewName("dashboard");
		model.addObject("successmsg", modelRedirect.asMap().get("msg"));
		return model;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("login");
		HttpSession session = request.getSession();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			session.removeAttribute(WebAppConstants.FLOWDATA);
			session.invalidate();
			flowData.clearAllSessionData();
			flowData.clearAllSessionDataObject();

			logger.info("logout succefully........");
		} catch (Exception e) {
			logger.error("Exception in LoginController:logout--->", e);
		}
		UserDetailsDto userDetailsDto = new UserDetailsDto();
		mv.addObject("userDetailsDto", userDetailsDto);
		return mv;
	}
	
	@RequestMapping("/new-user")
	public ModelAndView newUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model=new ModelAndView("new-user");
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			
			model.addObject("message","Hello user welcome...");
		} catch (Exception e) {
			// TODO: handle exception
		}
		model.addObject("employeeDto", new EmployeeDto());
		return model;
		
	}
	
	public ModelAndView getPostLoginDtls(FlowData flowData, HttpServletRequest request) {
		logger.info("LoginController:getPostLoginDtls start");
		ModelAndView mv = new ModelAndView();
		String viewName = "";
		try {
			viewName = "dashboard";
			mv = new ModelAndView(viewName);
			mv = super.getCommonSessionData(flowData, mv);
			
			if (mv == null) {
				return super.loginPage(flowData, request);
			}
			
			flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
			return mv;
		} catch (Exception e) {
			logger.error("Exception in LoginController:getPostLoginDtls", e);
		}
		logger.info(LoginController.class.getName() + ".inside user login controller END");
		return mv;
	}
	
	@RequestMapping(value="/forgot-password", method = RequestMethod.GET)
	public ModelAndView forgot(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model=new ModelAndView("forgot-password");
		try {
		
		} catch (Exception e) {
			// TODO: handle exception
		}
		model.addObject("userDetailsDto", new UserDetailsDto());
		return model;
	}
	
	
	@RequestMapping(value="/reset-password" , method = RequestMethod.POST)
	public ModelAndView resetPassword(@ModelAttribute ("userDetailsDto") UserDetailsDto userDetailsDto,HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse) {
		ModelAndView model = new ModelAndView();
		String employeeId = httpServletRequest.getParameter("employeeId");
		model.addObject("userDetailsDto", userDetailsDto);
		model.addObject("employeeId", userDetailsDto.getEmployeeId());
		model.setViewName("reset-password");
		return model;
	}
	
	@RequestMapping(value="/changeProfilePassword" , method = RequestMethod.GET)
	public ModelAndView changeProfilePassword() {
		ModelAndView model = new ModelAndView();
		UserDetailsDto userDetailsDto = new UserDetailsDto();
		model.addObject("userDetailsDto", userDetailsDto);
		model.setViewName("change-password");
		return model;
	}
	
	//Reset new password after forgot password
	@RequestMapping(value = "/change-password", method = RequestMethod.POST)
	public ModelAndView changePassword(@ModelAttribute ("userDetailsDto") UserDetailsDto userDetailsDto ,HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		Integer employeeId = Integer.parseInt(request.getParameter("employeeId"));
		String newPassword = request.getParameter("newPassword");
		Boolean result = false;
		try {
		result = loginServiceManager.resetPassword(employeeId,newPassword);
		} catch (HospitalExceptionHandler e) {
			logger.error("Error in LoginController- > changePassword", e);
			mv.addObject(WebAppConstants.ERROR_CODE, e.getErrorCode());
			mv.addObject(WebAppConstants.ERROR_MESSAGE, e.getDescription());
			mv.setViewName("resetPassword");
		} catch (Exception e) {
			logger.error("Error in LoginController- > changePassword", e);
			mv.setViewName("resetPassword");
		}
		mv.addObject("successMsg", "Password Has Been Changed Successfully..!!");
		mv.addObject("userDetailsDto", new UserDetailsDto());
		mv.setViewName("login");
		return mv;
	}
	
	
	
	@RequestMapping("/UI")
	public ModelAndView UI(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView("UI");
		try {

		} catch (Exception e) {
			// TODO: handle exception
		}
		return model;
	}


	
}
