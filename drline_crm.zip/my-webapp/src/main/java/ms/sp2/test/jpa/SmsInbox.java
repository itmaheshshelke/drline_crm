package ms.sp2.test.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="sms_inbox")
public class SmsInbox implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	@Column(name="sms_inbox_id")
	private Integer smsInboxId;
	
	@Column(name="sms_template_type")
	private String smsTemplateType;
	
	@Column(name="hospital_id")
	private Integer hospitalId;
	
	@Column(name="sms_transaction_id")
	private String smsTransactionId;
	
	@Column(name="service")
	private String service;
	
	@Column(name="status")
	private Integer status;

	public Integer getSmsInboxId() {
		return smsInboxId;
	}

	public void setSmsInboxId(Integer smsInboxId) {
		this.smsInboxId = smsInboxId;
	}

	public String getSmsTemplateType() {
		return smsTemplateType;
	}

	public void setSmsTemplateType(String smsTemplateType) {
		this.smsTemplateType = smsTemplateType;
	}

	public Integer getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(Integer hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getSmsTransactionId() {
		return smsTransactionId;
	}

	public void setSmsTransactionId(String smsTransactionId) {
		this.smsTransactionId = smsTransactionId;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	

	
}
