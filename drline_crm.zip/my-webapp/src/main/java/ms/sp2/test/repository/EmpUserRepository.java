/**
 21-Jan-2019* 
EmpUserRepository.java
 */
package ms.sp2.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ms.sp2.test.jpa.EmpUser;

public interface EmpUserRepository extends JpaRepository<EmpUser, Integer> {
	
	@Query("select u.userId from EmpUser u where u.empId= :empId")
	public Integer getEmpUserByEmpId(@Param("empId") Integer employeeId);

	@Query("select u from EmpUser u where u.empId= :employeeId")
	public EmpUser checkempUserexist(@Param("employeeId") Integer employeeId);
}
