package ms.sp2.test.constants;

public class SmsSettingsConstant {

	public static final String USERNAME = "";
	public static final String PASSWORD = "";
	public static final String SENDER_ID = "";
	public static final String STATUS = "1";
	public static final String URL = "https://aikonsms.co.in/control/smsapi.php?";
	
}
