package ms.sp2.test.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ms.sp2.test.dao.PropertiesDao;
import ms.sp2.test.dao.SmsDao;
import ms.sp2.test.dto.SmsProviderSettingDto;
import ms.sp2.test.dto.mapper.SmsProviderSettingMapper;
import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.exception.HospitalServiceErrors;
import ms.sp2.test.jpa.SmsProviderSetting;
import ms.sp2.test.jpa.Template;
import ms.sp2.test.util.SMSUtil;


@Component
public class SmsLogicImpl implements SmsLogic {

	Logger logger = LoggerFactory.getLogger(SmsLogicImpl.class);
	
	
	@Autowired
	private  PropertiesDao propertiesDao;
	
	@Autowired
	private  SmsDao smsDao;

		
	@Override
	public String sendSms(String mobileNo, String message, String service, String mode , int templateId,Integer branchId) throws HospitalExceptionHandler {
		String messageTransId="";
		boolean result = false;
		try {
			SmsProviderSetting smsConfig=null;
				SmsProviderSettingDto smsConfigDto=new SmsProviderSettingDto();
				smsConfigDto=propertiesDao.getSmsPropertiesById(1);
				if(smsConfigDto!=null) {
					smsConfig = new SmsProviderSetting();
					smsConfig = SmsProviderSettingMapper._toJpa(smsConfigDto);
				}

		if(smsConfig!=null) {
			//messageTransId= "Submitted | 549154856a1042053297";
			messageTransId = SMSUtil.sendSms(smsConfig, mobileNo, message, service, templateId);
			String[] s3 = messageTransId.trim().split("\\s");
			messageTransId = s3[2].trim(); // Submitted | 549154856a1042053297
			if (!messageTransId.equals("")) {
				result = smsDao.saveSms(mobileNo, service, mode, messageTransId ,templateId,branchId);
				if (!result) {
					logger.info("Error while sending sms");
					throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
				}else {
					logger.info("Sms Sent successfully");
				}
			}
		}
		} catch (HospitalExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > sendSms ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}
		return messageTransId;
	}
	
/*	public String sendOtp(String mobileNo, int siteId) throws HopsitalExceptionHandler{
		String otpNum="";
		try {
			
			int length = 4;

			String numbers = "0123456789";

			Random rndm_method = new Random();

			char[] otp = new char[length];

			for (int i = 0; i < length; i++) {
				otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
			}

			 otpNum = String.valueOf(otp);
			System.out.println(":====================" + otpNum);
			String content = "";
			
			if(!mobileNo.isEmpty()) {
				content = SMSTemplates.OTP_SENT;
				content = content.replaceAll("#1", otpNum);
				//content = content.replaceAll("#2", "\n");
				
			}
			sendSms(mobileNo, content, "TRANS", "Debug", 1, length);

		} catch (Exception e) {
			System.out.println("Exception while sending SMS to customer " + mobileNo);
		}
		return otpNum;
	}

	@Override
	public String getBalance(int siteId) throws HopsitalExceptionHandler {

		String result = "";
		try {
			SmsProviderSetting smsConfig = smsDaoImpl.getSmsConfig(siteId);
			result = SMSUtil.getBalance(smsConfig);
		} catch (HopsitalExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > getBalance ", e);
			throw new HopsitalExceptionHandler(HopsitalServiceErrors.GENERIC_EXCEPTION);
		}

		return result;

	}*/

	@Override
	public Template getSmsTemplateById(Integer templateId) throws HospitalExceptionHandler {
		Template template;
		String result = "";
		try {
			 template = smsDao.getSmsTempalte(templateId);
			
		} catch (HospitalExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > getBalance ", e);
			throw new HospitalExceptionHandler(HospitalServiceErrors.GENERIC_EXCEPTION);
		}

		return template;

	}

	
	/*@Override
	public String getDeleveryReport(String mobileNo, String messageId,int siteId) throws HopsitalExceptionHandler {

		String result = "";
		try {
			SmsProviderSetting smsConfig = smsDaoImpl.getSmsConfig(siteId);

			String status = SMSUtil.deleveryReport(smsConfig, messageId);
			// status=Mobile No : 9405408644 | Sent Time : 2017-08-12 12:14:24 |
			// Sender Name : GRENRY | Transaction Id : 549154856a1042053297 |
			// Service : TRANS | Status : DELIVERED | SMS Credit : 1";

			String[] s3 = status.split("\\s");
			status = s3[33];

			result = smsDaoImpl.getDeliveryReport(mobileNo, messageId, status);
			return result;
		} catch (HopsitalExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > getDeleveryReport ", e);
			throw new HopsitalExceptionHandler(HopsitalServiceErrors.GENERIC_EXCEPTION);
		}
	}

	public Boolean sendEmail(EmailMessage emailMessage, String email,
			String subject, String contents, Integer hospitalId) throws HopsitalExceptionHandler {
		Boolean result=false;
		EmailInbox emailInbox=new EmailInbox();
		try {
			HospitalEmailSetting	hospitalEmailSetting = hospitalEmailSettingDao.gethospitalEmailSettingById(1);
			HospitalEmailSettingDto hospitalEmailSettingDto=HospitalEmailSettingMapper._toDto(hospitalEmailSetting);
			
			result=EmailUtil.sendEmail(hospitalEmailSettingDto,emailMessage, email,subject, contents);
			
			emailInbox.setHospitalId(hospitalId);
			emailInbox.setEmailTemplateType(EmailConstant.NEW_CLINIC);
			emailInbox.setService(EmailConstant.TRANS);
			if(result==true) {
				emailInbox.setStatus(EmailConstant.SENT);
			}else {
				emailInbox.setStatus(EmailConstant.FAILED);
			}
			hospitalEmailSettingDao.saveEmail(emailInbox);
			
			} catch (HibernateException he) {
			logger.error("HibernateException Error in HospitalEmailSettingLogicImpl - > sendEmail ", he);
			throw new HopsitalExceptionHandler(HopsitalServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in HospitalEmailSettingLogicImpl - > sendEmail ", e);
			throw new HopsitalExceptionHandler(HopsitalServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}
*/

	
	
}
