package ms.sp2.test.dao;

import ms.sp2.test.exception.HospitalExceptionHandler;
import ms.sp2.test.jpa.SmsProviderSetting;
import ms.sp2.test.jpa.Template;

public interface SmsDao {

	public SmsProviderSetting getSmsConfig(int siteId) throws HospitalExceptionHandler;

	public boolean saveSms(String mobileNo, String route, String vendorId, String messageId, int templateId,Integer hospitalId)
			throws HospitalExceptionHandler;

	public String getDeliveryReport(String vendorId, String messageId, String status) throws HospitalExceptionHandler;

	public Template getSmsTempalte(Integer templateId)throws HospitalExceptionHandler;

}
