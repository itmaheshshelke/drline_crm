/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.1.72-community : Database - drline_crm
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`drline_crm` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `drline_crm`;

/*Table structure for table `email_inbox` */

DROP TABLE IF EXISTS `email_inbox`;

CREATE TABLE `email_inbox` (
  `email_inbox_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email_template_type` varchar(50) DEFAULT NULL,
  `email_transaction_id` int(10) DEFAULT NULL,
  `service` varchar(30) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`email_inbox_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `email_inbox` */

insert  into `email_inbox`(`email_inbox_id`,`email_template_type`,`email_transaction_id`,`service`,`status`) values (8,'New Employee Credentials.',36468,'TRANS',1),(9,'New Employee Credentials.',20214,'TRANS',1),(11,'New Employee Credentials.',81465,'TRANS',1);

/*Table structure for table `email_properties` */

DROP TABLE IF EXISTS `email_properties`;

CREATE TABLE `email_properties` (
  `email_properties_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_url` varchar(200) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `host` varchar(20) NOT NULL,
  `port` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`email_properties_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `email_properties` */

insert  into `email_properties`(`email_properties_id`,`template_url`,`email_id`,`host`,`port`,`password`) values (1,'C:\\\\email_templates\\\\','drline.care@gmail.com','smtp.gmail.com','587','DrLine@12345');

/*Table structure for table `emp_user` */

DROP TABLE IF EXISTS `emp_user`;

CREATE TABLE `emp_user` (
  `emp_user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `emp_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`emp_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `emp_user` */

insert  into `emp_user`(`emp_user_id`,`user_id`,`emp_id`) values (1,1,1),(2,2,2);

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `emp_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_name` varchar(30) DEFAULT NULL,
  `m_name` varchar(30) DEFAULT NULL,
  `l_name` varchar(30) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `contact_no1` varchar(20) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_on` date NOT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) NOT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `FK_employee` (`updated_by`),
  KEY `FK_employee_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `employee` */

insert  into `employee`(`emp_id`,`f_name`,`m_name`,`l_name`,`gender`,`contact_no1`,`email_id`,`created_by`,`created_on`,`updated_by`,`updated_on`,`del_flag`) values (1,'Mahesh',NULL,'Shelke','M','9922861410','it.maheshshelke@gmail.com',1,'2019-02-10',NULL,NULL,'N'),(2,'Shubham',NULL,'Mishra','M','8765476960','shubhammishra664@gmail.com',1,'2019-02-10',NULL,NULL,'N');

/*Table structure for table `excel` */

DROP TABLE IF EXISTS `excel`;

CREATE TABLE `excel` (
  `employee_id` int(11) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `del_flag` char(1) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `excel` */

insert  into `excel`(`employee_id`,`contact_no`,`created_by`,`created_on`,`del_flag`,`email_id`,`first_name`,`last_name`,`updated_by`,`updated_on`) values (1,'9922861410',1,'2019-02-09 12:39:25','Y','it.maheshshelke@gmail.com','Mahesh','Shelke',1,'2019-02-09 15:40:53'),(4,'9922861410',1,'2019-02-09 15:54:06','N','it.maheshshelke@gmail.com','Mahesh','Shelke',NULL,NULL),(5,'9922861410',1,'2019-02-09 15:54:06','N','it.maheshshelke@gmail.com','Ram','Shelke',NULL,NULL);

/*Table structure for table `hibernate_sequence` */

DROP TABLE IF EXISTS `hibernate_sequence`;

CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hibernate_sequence` */

insert  into `hibernate_sequence`(`next_val`) values (14),(14),(14),(14),(14),(14),(14),(14),(14);

/*Table structure for table `sms_inbox` */

DROP TABLE IF EXISTS `sms_inbox`;

CREATE TABLE `sms_inbox` (
  `sms_inbox_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sms_template_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hospital_id` int(10) NOT NULL,
  `sms_transaction_id` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`sms_inbox_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `sms_inbox` */

insert  into `sms_inbox`(`sms_inbox_id`,`sms_template_type`,`hospital_id`,`sms_transaction_id`,`service`,`status`) values (6,'NEW_EMPLOYEE',0,'277587855a2120875599','TRANS',1),(7,'NEW_EMPLOYEE',0,'1447490508a1727394512','TRANS',1),(10,'CLINIC_REGISTERED',0,'495781987b1432371013','TRANS',1),(12,'CLINIC_REGISTERED',0,'369074737a234450998','TRANS',1),(13,'CLINIC_REGISTERED',0,'214277789b977255414','TRANS',1);

/*Table structure for table `sms_provider_setting` */

DROP TABLE IF EXISTS `sms_provider_setting`;

CREATE TABLE `sms_provider_setting` (
  `sms_provider_setting_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provider_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `base_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sender_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`sms_provider_setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `sms_provider_setting` */

insert  into `sms_provider_setting`(`sms_provider_setting_id`,`provider_name`,`base_url`,`user_name`,`password`,`sender_id`) values (1,'Aikon SMS','https://aikonsms.co.in/control/smsapi.php?','doctospek','0dr_Spk%3@Tt','Drline');

/*Table structure for table `templates` */

DROP TABLE IF EXISTS `templates`;

CREATE TABLE `templates` (
  `template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_type` varchar(100) DEFAULT NULL,
  `sms_body` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

/*Data for the table `templates` */

insert  into `templates`(`template_id`,`template_type`,`sms_body`) values (1,'CLINIC_REGISTERED','Dear ##1,##2 Welcome to Drline!!! Your registration completed successfully. Your Payment process is remaining please complete it. ##3Thanks, Team Drline.'),(2,'CLINIC_ENQUIRY_BY_ONLINE','Dear ##1,##2 Welcome to Drline!!! Your primary registration is completed successfully. Kindly click on the following link to complete remaining process.##3Link : ##4 ##5Thanks, Team Drline.'),(3,'CLINIC_ENQUIRY_BY_REFERANCE','Dear ##1,##2 Welcome to Drline!!! Your primary registration is completed successfully. Kindly click on the following link to complete remaining process.##3Link : ##4 ##5Thanks, Team Drline.'),(4,'CLINIC_REFERANCE_PERSON','Dear ##1,##2 Welcome to Drline!!! By using your reference ##3 is registered successfully. If you are eligible for award then we will inform you... ##4Thanks, Team Drline.'),(5,'CLINIC_Bill_PAYMENT_SUCCESS','Dear ##1,##2 Welcome to Drline!!! Your payment of amount ##3 is received successfully. Your credentials are as follows.##4username : ##5 ##6password: ##7 ##8Login URL : admin.drline.in/drline-webapp/ ##9Thanks, Team Drline.'),(6,'CLINIC_Bill_PAYMENT_FAIL','Dear ##1,##2 Welcome to Drline!!! Your Payment is failed of amount ##3 .##4Thanks, Team Drline.'),(7,'CLINIC_SECOND_REF_AWARD','Dear ##1,##2 Welcome to Drline!!! You are eligible for award of amount ##3 from Drline for your reference. We request you to send your account details on our mail id customercare@drline.in. ##4Thanks, Team Drline.'),(8,'SEND_OTP','##1 is the One Time Password (OTP) for your account.Please DO NOT share this OTP with anyone. ##2Thanks, Team Drline.'),(9,'NEW_EMPLOYEE','Dear ##1,##2Welcome to ##3. Use bellow credentials to login into your account.##4User Id:##5##6Password:##7.##8Thank you.'),(10,'FUTURE_APPOINTMENT','Dear ##1,##2Your appointment with ##3 has been confirmed. Appointment Details: Date: ##4,Time: ##5. Clinic Address: ##6 Call ##7 for any queries. Thank you. ##8'),(11,'CANCEL_APPOINTMENT','Dear ##1,##2your appointment with ##3 on Date ##4 at ##5 has been canceled. For any query contact ##6. Thank you. ##7'),(12,'NEW_PATIENT','Dear ##1,##2your appointment with ##3 has been confirmed. Appointment Details: Clinic Address: ##4. Call on ##5 for any queries. Thank you. ##6'),(13,'PATIENT_REGISTERED','Dear ##1,##2Congratulations!!! You have been registered successfully on Drline. Kindly use the Username and Password given below to login into your account. ##3USERNAME : ##4 ##5PASSWORD : ##6 ##7Thank You.##space Click here ##link to download the Drline app'),(14,'BRANCH_REGISTERED','Dear ##1,##2 Welcome to ##3!!! Your registration completed successfully. Your Payment process is remaining please complete it. ##4Thanks, Team Drline.'),(15,'BRANCH_PAYMENT_FAIL','Dear ##1,##2 Welcome to Drline!!! Your Payment is failed of amount ##3 . We were unable to collect your payment.##4Thanks, Team Drline.'),(16,'APOINTMENT_REMINDER','Dear ##1,##space Your appointment with Dr. ##2 has been confirmed. Appointment Details:##space ##3 at : ##4, ##spaceClinic Address : ##5 ##spacePlease call on ##6 ,for any queries or to book appointment. ##spaceThank You,##space ##7'),(17,'APOINTMENT_REMINDER_DOC','Hello dr ##1,##2 We would like to inform you about your todays booked appointment list.##3  ##4 List is given below : ##5  ##6 ##7'),(18,'BDAY_SMS','Wishing you a day filled with happiness and a year filled with joy....'),(19,'LICEN_EXPIRY','Dear ##1,##2 Your license key of Clinic Application is Expiring within ##3. Please renew your license to continue uses of application. ##4Your license expires on  ##5 ##6Best Regards##7Team Drline.'),(20,'PAYMENT_REMINDER','Dear ##1,##2 This sms is being sent as a reminder that you have successfully registered on DrLine. But still we have not received your payment of Rs  ##3. ##4 Please click the link below to pay your invoice.##5 ##6 Best Regards ##7 Team Drline.');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `salt_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(10) DEFAULT NULL,
  `failed_attemt` int(10) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `user` */

insert  into `user`(`user_id`,`password`,`salt_password`,`status`,`failed_attemt`) values (1,'7ElXzAbDQm1SetzFOGo+u9E79DGl4jwKPCnrwDv2doc=','[B@682846ca',1,0),(2,'7ElXzAbDQm1SetzFOGo+u9E79DGl4jwKPCnrwDv2doc=','[B@682846ca',1,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
